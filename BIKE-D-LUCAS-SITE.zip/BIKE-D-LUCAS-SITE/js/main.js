/* ===========================================================
   BIKE D'LUCAS — Interações
   =========================================================== */
document.addEventListener('DOMContentLoaded', () => {

  /* ---- Header: muda de estilo ao rolar ---- */
  const header = document.querySelector('.header');
  const onScroll = () => {
    if (window.scrollY > 40) header.classList.add('scrolled');
    else header.classList.remove('scrolled');
  };
  onScroll();
  window.addEventListener('scroll', onScroll, { passive:true });

  /* ---- Menu mobile ---- */
  const toggle = document.querySelector('.menu-toggle');
  const navMobile = document.querySelector('.nav-mobile');
  if (toggle && navMobile){
    toggle.addEventListener('click', () => {
      navMobile.classList.toggle('aberto');
      toggle.classList.toggle('aberto');
    });
    navMobile.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => navMobile.classList.remove('aberto'));
    });
  }

  /* ---- Revelação suave ao rolar (substitui bibliotecas externas pesadas) ---- */
  const revelaveis = document.querySelectorAll('[data-reveal]');
  const observer = new IntersectionObserver((entradas) => {
    entradas.forEach(entrada => {
      if (entrada.isIntersecting){
        entrada.target.classList.add('visivel');
        observer.unobserve(entrada.target);
      }
    });
  }, { threshold:0.15, rootMargin:'0px 0px -60px 0px' });
  revelaveis.forEach((el, i) => {
    el.style.setProperty('--i', i % 8);
    observer.observe(el);
  });

  /* ---- FAQ accordion ---- */
  document.querySelectorAll('.faq-item').forEach(item => {
    const pergunta = item.querySelector('.faq-pergunta');
    const resposta = item.querySelector('.faq-resposta');
    pergunta.addEventListener('click', () => {
      const aberto = item.classList.contains('aberto');
      document.querySelectorAll('.faq-item.aberto').forEach(outro => {
        if (outro !== item){
          outro.classList.remove('aberto');
          outro.querySelector('.faq-resposta').style.maxHeight = null;
        }
      });
      if (aberto){
        item.classList.remove('aberto');
        resposta.style.maxHeight = null;
      } else {
        item.classList.add('aberto');
        resposta.style.maxHeight = resposta.scrollHeight + 'px';
      }
    });
  });

  /* ---- Lightbox da galeria ---- */
  const lightbox = document.querySelector('.lightbox');
  if (lightbox){
    const imgLightbox = lightbox.querySelector('img');
    const legenda = lightbox.querySelector('.lightbox-legenda');
    document.querySelectorAll('.g-item').forEach(item => {
      item.addEventListener('click', () => {
        const img = item.querySelector('img');
        imgLightbox.src = img.src;
        imgLightbox.alt = img.alt;
        legenda.textContent = img.alt;
        lightbox.classList.add('ativo');
      });
    });
    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox || e.target.closest('.lightbox-fechar')) {
        lightbox.classList.remove('ativo');
      }
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') lightbox.classList.remove('ativo');
    });
  }

  /* ---- Formulário de contato: monta uma mensagem para WhatsApp ---- */
  const form = document.querySelector('.form-contato');
  if (form){
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const nome = form.nome.value.trim();
      const telefone = form.telefone.value.trim();
      const loja = form.loja.value;
      const mensagem = form.mensagem.value.trim();

      const numeroWhats = form.dataset.whatsapp; // preencher no HTML quando o número existir
      const texto = encodeURIComponent(
        `Olá! Meu nome é ${nome}.\nTelefone: ${telefone}\nLoja de interesse: ${loja}\nMensagem: ${mensagem}`
      );

      if (numeroWhats){
        window.open(`https://wa.me/${numeroWhats}?text=${texto}`, '_blank');
      } else {
        alert('O envio pelo WhatsApp será ativado assim que o número da loja for cadastrado. Por enquanto, entre em contato pelo telefone ou Instagram informados na página.');
      }
    });
  }

});
