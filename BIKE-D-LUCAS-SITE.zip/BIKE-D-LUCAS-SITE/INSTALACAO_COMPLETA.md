---
title: "Guia de Instalação — Bike D'Lucas"
---

# Guia de Instalação e Manutenção do Site — Bike D'Lucas

Este guia foi escrito para quem **não** mexe com programação. Siga os passos na ordem.

## 1. Estrutura do projeto

A pasta `SITE` contém:

- `index.html` — a página inicial (home)
- `guia-do-ciclista.html` — a página de conteúdo educativo
- `css/style.css` — o arquivo que controla toda a aparência (cores, espaçamentos, fontes)
- `js/main.js` — o arquivo que controla as interações (menu, galeria com zoom, perguntas frequentes, formulário)
- `img/` — todas as imagens usadas no site
- `robots.txt` e `sitemap.xml` — arquivos técnicos que ajudam o Google a encontrar o site

Você **não precisa entender** o conteúdo desses arquivos para fazer alterações simples — basta seguir os passos abaixo.

## 2. Como abrir o site no seu computador

1. Descompacte o arquivo `BIKE-D-LUCAS-SITE.zip`, se ainda não fez isso.
2. Entre na pasta `SITE`.
3. Dê duplo clique em `index.html`.
4. O site vai abrir no seu navegador (Chrome, Edge, Firefox), como se estivesse no ar. Isso serve para você conferir alterações antes de publicar.

## 3. Como publicar o site (colocar no ar)

Você vai precisar de uma **hospedagem** (empresa que "guarda" o site na internet) e, de preferência, um **domínio** (endereço, ex: `www.bikedlucas.com.br`).

Passos gerais (o nome exato dos botões muda conforme a hospedagem escolhida):

1. Contrate uma hospedagem simples (hospedagem compartilhada de sites, não precisa ser de "aplicativo" nem "banco de dados").
2. Acesse o **Gerenciador de Arquivos** (ou use um programa de FTP, como o FileZilla) fornecido pela sua hospedagem.
3. Envie **todo o conteúdo de dentro da pasta `SITE`** (não a pasta `SITE` em si, o conteúdo dela) para a pasta principal do site, geralmente chamada `public_html` ou `www`.
4. Aguarde alguns minutos e acesse seu domínio no navegador para conferir.

Se preferir, qualquer serviço de hospedagem gratuita de sites estáticos (que aceite arquivos HTML comuns) também funciona, já que o site não depende de nenhum banco de dados ou instalação especial.

## 4. Como adicionar o número do WhatsApp

Isso foi deixado propositalmente em branco para você preencher.

**No arquivo `index.html`:**

Use a ferramenta "Localizar e substituir" do seu editor de texto (ou Bloco de Notas) e procure pelo texto `btn-disabled`. Você vai encontrar trechos assim:

```html
<a href="#" class="btn btn-primario btn-disabled" title="Cadastre o número do WhatsApp...">
  WhatsApp
</a>
```

Troque por (usando o número real, com código do país 55 e DDD, sem espaços ou traços):

```html
<a href="https://wa.me/5547999999999" target="_blank" class="btn btn-primario">
  WhatsApp
</a>
```

Repita para cada botão de WhatsApp (topo do site, cada loja, botão flutuante no canto da tela, e o campo `data-whatsapp=""` do formulário de contato — coloque o número entre as aspas, exemplo: `data-whatsapp="5547999999999"`).

**Botão flutuante:** procure por `wpp-flutuante indisponivel` no `index.html`, remova a palavra `indisponivel` da classe e coloque o link `https://wa.me/55SEUNUMERO` no `href="#"`.

## 5. Como alterar o horário de funcionamento

No arquivo `index.html`, procure pelo texto `(confirmar)`. Você vai ver dois trechos parecidos com:

```html
<span data-horario-matriz>Seg. a Sáb., 9h às 18h <em style="opacity:.6">(confirmar)</em></span>
```

Apague o `<em style="opacity:.6">(confirmar)</em>` e escreva o horário real no lugar do texto `Seg. a Sáb., 9h às 18h`. Faça isso para as duas lojas (procure `data-horario-matriz` e `data-horario-filial`).

Também remova a frase de aviso logo abaixo dos cartões de loja: procure por `* Horários marcados como "confirmar"` e apague a linha inteira (a tag `<p>` correspondente).

## 6. Como alterar textos

Abra o arquivo `.html` da página desejada com o Bloco de Notas (Windows) ou TextEdit em modo texto simples (Mac), ou um editor como o Notepad++ / VS Code (recomendado, é gratuito).

Localize o texto que deseja mudar — ele aparece exatamente como no site — e substitua apenas o texto, sem apagar os símbolos `< >` ao redor. Exemplo:

```html
<h1 class="hero-titulo">Sua próxima pedalada começa aqui</h1>
```

Você pode mudar apenas a frase `Sua próxima pedalada começa aqui`, mantendo as tags intactas.

## 7. Como trocar imagens

1. Prepare a nova imagem com um nome parecido (ex: `mountain.png`) e, se possível, dimensões parecidas com a original.
2. Coloque o novo arquivo dentro da pasta `img/`, substituindo o antigo (mesmo nome).

Se quiser usar um nome de arquivo diferente, também é possível — mas nesse caso você precisa encontrar a referência antiga dentro do `.html` (ex: `src="img/mountain.png"`) e trocar pelo novo nome.

> **Nota sobre qualidade:** algumas imagens fornecidas para este projeto (fotos de produto e das lojas) têm resolução baixa. Ao ampliar muito a tela ou usar telas de alta resolução, elas podem parecer um pouco borradas. Recomendamos substituir por fotos em maior resolução assim que possível — principalmente as fotos das fachadas das lojas e da galeria.

## 8. Como alterar telefones

No arquivo `index.html`, procure pelo número atual (ex: `3427-1985`) usando "Localizar e substituir" e troque em todos os lugares em que aparece — tanto no texto visível quanto nos links `tel:+554734271985` (mantenha o formato `tel:+55` seguido do DDD e do número, sem espaços).

## 9. Como alterar redes sociais

Procure por `instagram.com/bikedlucas` ou `facebook.com/profile.php` no `index.html` e no `guia-do-ciclista.html`, e substitua pelo link correto nos trechos `href="..."`.

## 10. Como alterar endereço

Procure pelo endereço atual (ex: `Rua Ponte Serrada, 806`) e substitua pelo texto correto. Se o endereço mudar, atualize também o link do botão "Como chegar", que usa este formato:

```
https://www.google.com/maps/dir/?api=1&destination=Rua+Nome+da+Rua+Numero+Joinville+SC
```

Troque os espaços por `+` dentro do endereço.

## 11. Como alterar as cores

Abra `css/style.css` e localize o bloco no topo do arquivo, que começa com `:root{`. As cores principais estão ali, nomeadas:

```css
--preto: #0d0d0d;      /* fundo escuro */
--vermelho: #e30613;   /* cor principal (botões, destaques) */
--dourado: #f2b705;    /* cor secundária (detalhes) */
--branco: #faf9f6;     /* fundo claro */
```

Troque apenas o código de cor (o texto que começa com `#`) — todo o site vai se atualizar automaticamente, porque essas cores são usadas em todo o site a partir desse único lugar.

## 12. Como atualizar futuramente

- Para pequenas mudanças de texto, imagem ou telefone: siga os passos acima.
- Para mudanças maiores de estrutura (nova seção, nova página), recomendamos contar com ajuda de alguém com conhecimento em HTML/CSS, para manter o site consistente.
- Sempre faça uma cópia de segurança da pasta `SITE` antes de editar, para poder desfazer caso algo dê errado.

## Dúvidas comuns

**O site ficou diferente depois que eu editei — o que fazer?**
Verifique se você não apagou nenhum sinal `< >`, `"` ou `{ }` sem querer. Um editor como o VS Code (gratuito) avisa quando algo está errado com cores diferentes no texto.

**Preciso instalar algum programa para o site funcionar?**
Não. O site não depende de instalação nenhuma — só precisa estar hospedado (colocado no ar) em qualquer serviço de hospedagem de sites.

**O site funciona no celular?**
Sim, o site foi construído para se adaptar automaticamente a celulares, tablets e computadores.
