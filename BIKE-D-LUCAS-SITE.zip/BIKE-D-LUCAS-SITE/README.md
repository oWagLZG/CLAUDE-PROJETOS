# Bike D'Lucas — Site Institucional

Site institucional (não é loja virtual) da Bike D'Lucas, feito em HTML, CSS e JavaScript puros — sem frameworks, sem instalação de programas, sem build. É só abrir e publicar.

## O que tem nesta pasta

```
SITE/
├── index.html              → página inicial
├── guia-do-ciclista.html   → página educativa (tipos de bike, capacete, cadeirinha, aros)
├── robots.txt               → arquivo técnico de SEO
├── sitemap.xml               → arquivo técnico de SEO
├── css/
│   └── style.css            → todo o visual do site (cores, espaçamentos, fontes)
├── js/
│   └── main.js               → interações (menu, galeria, FAQ, formulário)
├── img/                       → todas as imagens do site
└── INSTALACAO_COMPLETA.md/.pdf → guia passo a passo para quem não programa
```

## ⚠️ Duas coisas para preencher antes de publicar

O usuário pediu para deixar estes dois pontos em branco, marcados no site, para preencher depois:

1. **Número de WhatsApp** — todos os botões de WhatsApp estão desativados (cinza) até você adicionar o número. Veja "Como adicionar o WhatsApp" no `INSTALACAO_COMPLETA.md`.
2. **Horário de funcionamento** — está com o texto "confirmar" ao lado do horário provisório. Veja "Como alterar o horário" no mesmo arquivo.

O guia completo, escrito para quem não mexe com código, está em **INSTALACAO_COMPLETA.md** (e em PDF). Comece por ele.

## Resumo rápido

- **Abrir localmente:** dê duplo clique em `index.html`.
- **Publicar:** envie a pasta inteira (mantendo a estrutura de pastas) para qualquer hospedagem — funciona em qualquer plano que aceite arquivos HTML comuns.
- **Editar textos:** abra o arquivo `.html` desejado com o Bloco de Notas (ou similar) e altere o texto entre as tags.
- **Trocar imagens:** substitua o arquivo dentro de `img/` mantendo o mesmo nome, ou troque o nome do arquivo referenciado no HTML.

Todos os detalhes, com exemplos, estão no `INSTALACAO_COMPLETA.md`.
