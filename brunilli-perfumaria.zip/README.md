# Brunilli Perfumaria — site + painel administrativo

Site institucional (vitrine, sem carrinho/pagamento) em HTML+CSS+JS puro no
front-end, com painel administrativo em PHP puro e dados em arquivos JSON
(sem banco de dados). Feito para hospedagem compartilhada comum (Hostinger,
HostGator, Locaweb etc.).

## 1. Antes de subir para a hospedagem — o que você PRECISA ajustar

O site funciona assim como está, mas com dados de contato fictícios. Troque
o quanto antes pelo painel (`/admin`) ou direto nos arquivos:

- **WhatsApp**: `config/config.json` → `whatsappNumero` está como
  `5500000000000`. Sem isso os botões de compra não funcionam de verdade.
- **Instagram**: `instagramUsuario` está como `brunilli.perfumaria` —
  confirme se é o usuário real.
- **Senha do painel**: a senha inicial é `brunilli2026`. Troque assim que
  entrar pela primeira vez, em Configurações → Segurança.
- **Fichas técnicas dos perfumes**: por não ter recebido notas olfativas,
  fixação, projeção, ocasião e estação de cada produto, esses campos foram
  deixados como `"A confirmar"` — eles aparecem assim na página de cada
  produto até você preencher pelo painel (Produtos → Editar).
- **Endereço e telefone**: também estão como texto de exemplo.

## 2. Como hospedar (Hostinger, HostGator, Locaweb, cPanel em geral)

1. Compacte todo o conteúdo desta pasta (não a pasta em si, o *conteúdo*
   dela) em um .zip.
2. No painel de hospedagem, vá até o Gerenciador de Arquivos, entre em
   `public_html` (ou `htdocs`) e envie o .zip.
3. Extraia o .zip dentro de `public_html`.
4. Confirme que a versão do PHP do plano é 8.0 ou superior (Configurações
   → PHP no painel de hospedagem).
5. Acesse `https://seudominio.com.br/admin` para entrar no painel.
6. Ative o SSL grátis (Let's Encrypt) no painel de hospedagem e, depois de
   confirmar que está funcionando, descomente as linhas de redirecionamento
   HTTPS no `.htaccess` da raiz.

Não é necessário configurar banco de dados — o site não usa nenhum.

## 3. Estrutura de pastas

```
/                     páginas públicas (index.html)
/pages/               catálogo e página de produto
/assets/              css, js, imagens e logo
/database/            produtos.json (catálogo)
/config/              config.json (dados públicos) e admin.json (senha — protegido)
/includes/            funções PHP internas (não acessível pela URL)
/admin/               painel administrativo (login obrigatório)
/admin/actions/       endpoints PHP chamados pelo painel (todos exigem sessão logada)
/uploads/              pasta reservada para uploads futuros fora do catálogo
```

## 4. Segurança — o que já foi tratado e o que fica por sua conta

Tratado neste projeto:
- Senha do admin gravada com hash (bcrypt), nunca em texto puro.
- `config/admin.json` (onde fica o hash) bloqueado por `.htaccess` — não é
  acessível por URL, só lido pelo PHP no servidor.
- Bloqueio de força bruta simples: 5 tentativas erradas de senha e a sessão
  fica bloqueada por 60 segundos.
- Upload de imagem valida o tipo real do arquivo (não confia na extensão),
  limita a 5MB e bloqueia execução de PHP dentro da pasta de uploads.
- Toda gravação em JSON usa lock de arquivo + escrita atômica, para reduzir
  o risco de corromper o arquivo se duas ações acontecerem ao mesmo tempo.

Por sua conta:
- Troque a senha padrão antes de divulgar o site.
- Mantenha o PHP da hospedagem atualizado.
- Faça backup periódico da pasta `database/` e `config/` (são os únicos
  dados que não estão em nenhum outro lugar).

## 5. Sobre o sitemap.xml e robots.txt

Ambos têm `SEU-DOMINIO-AQUI.com.br` como placeholder — substitua pelo
domínio real depois de publicar (busca e substitui em `sitemap.xml` e
`robots.txt`).

## 6. O que este projeto propositalmente NÃO inclui

Conforme o briefing original: carrinho de compras, checkout ou pagamento
online. Toda venda é fechada manualmente pelo Instagram ou WhatsApp — os
botões dos produtos só abrem a conversa com a mensagem já preenchida.
