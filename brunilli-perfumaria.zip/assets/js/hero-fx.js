/**
 * BRUNILLI PERFUMARIA — hero-fx.js
 * ---------------------------------------------------------------
 * Sequência de entrada do hero: cortina que abre, texto revelado em
 * cascata, o frasco "materializando" (desfoque + escala + partículas
 * convergindo) e, depois disso, um spotlight que segue o mouse pelo
 * hero inteiro e botões com atração magnética ao cursor.
 *
 * Usa GSAP (obrigatório para toda a sequência) e Anime.js (só para o
 * burst de partículas — se não carregar, cai num fallback em GSAP puro
 * pras partículas, e o resto da entrada acontece normalmente).
 *
 * Se o GSAP não carregar por algum motivo (CDN fora do ar etc.), o
 * conteúdo aparece direto, sem animação — a cortina nunca fica travada
 * cobrindo a página.
 */

document.addEventListener('DOMContentLoaded', () => {
  const curtainL = document.querySelector('.hero-curtain-l');
  const curtainR = document.querySelector('.hero-curtain-r');
  const fxEls = document.querySelectorAll('.hero-fx');
  const bottle = document.getElementById('bottle3d');
  const particlesHolder = document.getElementById('bottle3d-particles');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (!window.gsap) {
    if (curtainL) curtainL.style.display = 'none';
    if (curtainR) curtainR.style.display = 'none';
    fxEls.forEach((el) => (el.style.opacity = 1));
    if (bottle) bottle.style.opacity = 1;
    return;
  }

  if (reduceMotion) {
    gsap.set([curtainL, curtainR], { display: 'none' });
    gsap.to(fxEls, { opacity: 1, duration: 0.5 });
    if (bottle) gsap.to(bottle, { opacity: 1, duration: 0.5 });
    return;
  }

  gsap.set(fxEls, { y: 24 });
  if (bottle) gsap.set(bottle, { opacity: 0, scale: 0.55, rotateY: -55, filter: 'blur(18px)', transformPerspective: 800 });

  const tl = gsap.timeline({ defaults: { ease: 'power4.inOut' } });
  tl.to(curtainL, { xPercent: -100, duration: 1.1 }, 0.15)
    .to(curtainR, { xPercent: 100, duration: 1.1 }, 0.15)
    .to(fxEls, { opacity: 1, y: 0, duration: 0.85, ease: 'power3.out', stagger: 0.12 }, 0.55)
    .to(bottle, { opacity: 1, scale: 1, rotateY: -8, filter: 'blur(0px)', duration: 1.3, ease: 'expo.out' }, 0.75)
    .call(burstParticles, null, 0.85);

  /* -------------------- Burst de partículas ao materializar o frasco -------------------- */
  function burstParticles() {
    if (!particlesHolder) return;
    const n = window.innerWidth < 700 ? 10 : 20;
    const dots = [];
    for (let i = 0; i < n; i++) {
      const d = document.createElement('span');
      d.className = 'bottle3d-particle';
      const angle = Math.random() * Math.PI * 2;
      const dist = 70 + Math.random() * 110;
      d._fromX = Math.cos(angle) * dist;
      d._fromY = Math.sin(angle) * dist;
      particlesHolder.appendChild(d);
      dots.push(d);
    }

    try {
      const animeFn = window.anime && window.anime.animate;
      if (animeFn) {
        dots.forEach((d, i) => {
          d.style.transform = `translate(${d._fromX}px, ${d._fromY}px) scale(1)`;
          d.style.opacity = '0.9';
          animeFn(d, {
            translateX: 0, translateY: 0, scale: 0, opacity: [0.9, 0],
            duration: 900 + Math.random() * 500,
            delay: i * 22,
            easing: 'easeOutExpo',
          });
        });
      } else {
        throw new Error('anime.js indisponível — usando fallback GSAP');
      }
    } catch (err) {
      dots.forEach((d, i) => {
        gsap.fromTo(
          d,
          { x: d._fromX, y: d._fromY, scale: 1, opacity: 0.9 },
          { x: 0, y: 0, scale: 0, opacity: 0, duration: 1, delay: i * 0.022, ease: 'expo.out' }
        );
      });
    }
    setTimeout(() => dots.forEach((d) => d.remove()), 2200);
  }

  /* -------------------- Spotlight que acompanha o mouse no hero -------------------- */
  const hero = document.querySelector('.hero');
  if (hero) {
    const state = { x: 60, y: 35 };
    const setX = gsap.quickTo(state, 'x', { duration: 0.7, ease: 'power3' });
    const setY = gsap.quickTo(state, 'y', { duration: 0.7, ease: 'power3' });
    hero.addEventListener('mousemove', (e) => {
      const rect = hero.getBoundingClientRect();
      setX(((e.clientX - rect.left) / rect.width) * 100);
      setY(((e.clientY - rect.top) / rect.height) * 100);
    });
    gsap.ticker.add(() => {
      hero.style.setProperty('--sx', state.x + '%');
      hero.style.setProperty('--sy', state.y + '%');
    });
  }

  /* -------------------- Botões com atração magnética -------------------- */
  document.querySelectorAll('.magnetic').forEach((btn) => {
    const setX = gsap.quickTo(btn, 'x', { duration: 0.5, ease: 'power3' });
    const setY = gsap.quickTo(btn, 'y', { duration: 0.5, ease: 'power3' });
    btn.addEventListener('mousemove', (e) => {
      const rect = btn.getBoundingClientRect();
      setX((e.clientX - (rect.left + rect.width / 2)) * 0.35);
      setY((e.clientY - (rect.top + rect.height / 2)) * 0.5);
    });
    btn.addEventListener('mouseleave', () => {
      setX(0);
      setY(0);
    });
  });
});
