/**
 * BRUNILLI PERFUMARIA — hero3d.js
 * ---------------------------------------------------------------
 * Interação CONTÍNUA do frasco no hero (depois que a entrada em
 * assets/js/hero-fx.js já terminou): tilt em perspectiva que segue o
 * mouse, brilho que acompanha o cursor (mascarado pelas áreas claras
 * da própria foto), giro manual por arraste com inércia, e uma
 * flutuação lenta e contínua.
 *
 * Só imagem + CSS/JS — sem WebGL, sem arquivo 3D. Funciona em
 * qualquer hospedagem.
 */

document.addEventListener('DOMContentLoaded', () => {
  const wrap = document.getElementById('bottle3d');
  const tilt = document.getElementById('bottle3d-tilt');
  if (!wrap || !tilt) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const shine = wrap.querySelector('.bottle3d-shine');

  const MAX_TILT = 14;
  let targetRX = 0, targetRY = 0;
  let curRX = 0, curRY = 0;
  let dragRotY = 0;
  let dragVelocity = 0;
  let dragging = false;
  let lastPointerX = 0;

  /* Flutuação lenta e contínua, começando só depois que a entrada
     (hero-fx.js) já materializou o frasco — evita disputar o mesmo
     momento de entrada com outra animação. */
  if (window.gsap && !reduceMotion) {
    gsap.to('.bottle3d-float', {
      y: -12, duration: 3.6, ease: 'sine.inOut', yoyo: true, repeat: -1, delay: 2.2,
    });
  }

  function onMouseMove(e) {
    if (dragging) return;
    const rect = wrap.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width;
    const py = (e.clientY - rect.top) / rect.height;
    if (px < -0.4 || px > 1.4 || py < -0.4 || py > 1.4) return;

    targetRY = (px - 0.5) * MAX_TILT * 2;
    targetRX = -(py - 0.5) * MAX_TILT * 1.4;

    if (shine) {
      shine.style.setProperty('--mx', (px * 100).toFixed(1) + '%');
      shine.style.setProperty('--my', (py * 100).toFixed(1) + '%');
    }
  }
  window.addEventListener('mousemove', onMouseMove, { passive: true });

  function dragStart(clientX) {
    dragging = true;
    lastPointerX = clientX;
    dragVelocity = 0;
    tilt.classList.add('is-dragging');
  }
  function dragMove(clientX) {
    if (!dragging) return;
    const delta = clientX - lastPointerX;
    lastPointerX = clientX;
    dragRotY += delta * 0.35;
    dragVelocity = delta * 0.35;
  }
  function dragEnd() {
    dragging = false;
    tilt.classList.remove('is-dragging');
  }

  wrap.addEventListener('mousedown', (e) => dragStart(e.clientX));
  window.addEventListener('mousemove', (e) => dragMove(e.clientX));
  window.addEventListener('mouseup', dragEnd);
  wrap.addEventListener('touchstart', (e) => dragStart(e.touches[0].clientX), { passive: true });
  wrap.addEventListener('touchmove', (e) => dragMove(e.touches[0].clientX), { passive: true });
  wrap.addEventListener('touchend', dragEnd);

  function tick() {
    requestAnimationFrame(tick);
    curRX += (targetRX - curRX) * 0.08;
    curRY += (targetRY - curRY) * 0.08;
    if (!dragging) {
      dragRotY += dragVelocity;
      dragVelocity *= 0.94;
      if (Math.abs(dragVelocity) < 0.01) dragVelocity = 0;
    }
    tilt.style.transform = `rotateX(${curRX.toFixed(2)}deg) rotateY(${(curRY + dragRotY).toFixed(2)}deg)`;
  }

  if (reduceMotion) {
    tilt.style.transform = 'rotateX(3deg) rotateY(-8deg)';
  } else {
    tick();
  }

  wrap.addEventListener('mouseleave', () => {
    if (dragging) return;
    targetRX = 0;
    targetRY = 0;
    if (shine) {
      shine.style.setProperty('--mx', '50%');
      shine.style.setProperty('--my', '25%');
    }
  });
});
