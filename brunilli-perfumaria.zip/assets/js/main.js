/* =========================================================
   BRUNILLI PERFUMARIA — main.js
   Comportamentos compartilhados por todas as páginas públicas.
   ========================================================= */

/* Calcula a raiz do site a partir do próprio <script src="...main.js">,
   para que fetch('config/config.json') funcione tanto em /index.html quanto
   em /pages/catalogo.html e /pages/produto.html. Sem isso, a partir de
   /pages/ o navegador tentava buscar /pages/config/config.json (404) e a
   página inteira ficava em branco, porque as promises rejeitavam antes de
   qualquer conteúdo ser renderizado. */
const BP_BASE = (() => {
  const atual = document.currentScript;
  const src = atual ? atual.src : (document.querySelector('script[src*="assets/js/main.js"]') || {}).src;
  if (!src) return './';
  return src.replace(/assets\/js\/main\.js.*$/, '');
})();

const BP = {
  config: null,
  produtos: [],

  async loadConfig() {
    if (this.config) return this.config;
    const res = await fetch(BP_BASE + 'config/config.json', { cache: 'no-store' });
    if (!res.ok) throw new Error('Não foi possível carregar config.json (' + res.status + ')');
    this.config = await res.json();
    return this.config;
  },

  async loadProdutos() {
    if (this.produtos.length) return this.produtos;
    const res = await fetch(BP_BASE + 'database/produtos.json', { cache: 'no-store' });
    if (!res.ok) throw new Error('Não foi possível carregar produtos.json (' + res.status + ')');
    this.produtos = await res.json();
    return this.produtos;
  },

  waLink(numero, nomeProduto) {
    const msg = nomeProduto
      ? `Olá, gostaria de saber mais sobre o perfume ${nomeProduto}.`
      : 'Olá, gostaria de saber mais sobre os perfumes da Brunilli Perfumaria.';
    return `https://wa.me/${numero}?text=${encodeURIComponent(msg)}`;
  },

  /* O Instagram não oferece nenhum link público que abra a conversa E já
     preencha o texto (diferente do WhatsApp com wa.me). O link oficial da
     Meta para abrir a conversa direta com um perfil específico é
     ig.me/m/<usuario> — funciona no app mobile e cai no site em desktop.
     Como não dá para pré-preencher o texto, copiamos a mensagem sugerida
     para a área de transferência e avisamos a pessoa para colar. */
  igDmLink(usuario) {
    return `https://ig.me/m/${usuario}`;
  },

  igMensagem(nomeProduto) {
    return nomeProduto
      ? `Olá, gostaria de saber mais sobre o perfume ${nomeProduto}.`
      : 'Olá, gostaria de saber mais sobre os perfumes da Brunilli Perfumaria.';
  },

  async igClick(usuario, nomeProduto, botaoEl) {
    const msg = this.igMensagem(nomeProduto);
    try {
      if (navigator.clipboard) await navigator.clipboard.writeText(msg);
      mostrarToast(botaoEl, 'Mensagem copiada — é só colar na conversa');
    } catch (err) {
      // clipboard pode falhar (ex: página aberta sem HTTPS); segue o fluxo mesmo assim
    }
    window.open(this.igDmLink(usuario), '_blank', 'noopener');
  },
};

document.addEventListener('DOMContentLoaded', async () => {
  warnIfFileProtocol();
  try {
    await BP.loadConfig();
    applyBrand();
  } catch (err) {
    console.error('Falha ao carregar config.json:', err);
  }
  initHeader();
  initMobileMenu();
  initReveal();
  initPetals();
  initVapor();
  initWhatsFloat();
  initLightbox();
  initLenis();
});

/* Scroll suave via Lenis (carregado por CDN). Só ativa se a lib carregou
   e a pessoa não pediu "reduzir movimento" no sistema — nunca quebra o
   site se a CDN falhar, é só uma melhoria de sensação de scroll. */
function initLenis() {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion || typeof Lenis === 'undefined') return;
  try {
    BP.lenis = new Lenis({ duration: 1.1, autoRaf: true, wheelMultiplier: 1 });
    if (window.gsap && window.ScrollTrigger) {
      BP.lenis.on('scroll', ScrollTrigger.update);
    }
  } catch (err) {
    console.warn('Lenis não pôde iniciar:', err);
  }
}

/* Se alguém abrir o HTML direto no navegador (duplo clique, sem servidor),
   fetch() de arquivos locais é bloqueado por segurança em todos os
   navegadores — e a página fica em branco, sem nenhum erro visível.
   Isso não é um bug do site: é uma restrição do próprio navegador para
   qualquer site que usa fetch(). Avisamos a pessoa em vez de deixar tela
   branca silenciosa. */
function warnIfFileProtocol() {
  if (window.location.protocol !== 'file:') return;
  const aviso = document.createElement('div');
  aviso.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:9999;background:#3E2B4A;color:#fff;padding:14px 20px;font-family:sans-serif;font-size:13px;text-align:center;';
  aviso.innerHTML = 'Este site precisa ser acessado por um servidor (http://), não abrindo o arquivo direto. Publique-o na hospedagem ou rode <code>php -S localhost:8000</code> na pasta do site e acesse http://localhost:8000 — veja o README.';
  document.body.prepend(aviso);
}

function fatalError(seletor, mensagem) {
  const el = document.querySelector(seletor);
  if (el) {
    el.innerHTML = `<div style="padding:60px 20px;text-align:center;color:#6E5F76;">
      <p style="font-family:'Cormorant Garamond',serif;font-size:1.4rem;color:#3E2B4A;margin-bottom:8px;">Não foi possível carregar esta página.</p>
      <p style="font-size:.9rem;">${mensagem}</p>
    </div>`;
  }
  console.error(mensagem);
}

function applyBrand() {
  const c = BP.config;
  if (!c) return;
  document.querySelectorAll('[data-brand-name]').forEach(el => (el.textContent = c.nomeLoja));
  document.querySelectorAll('[data-brand-slogan]').forEach(el => (el.textContent = c.slogan));
  document.querySelectorAll('[data-brand-about]').forEach(el => (el.textContent = c.textoInstitucional));
  document.querySelectorAll('[data-brand-logo]').forEach(el => (el.src = c.logo));
  document.querySelectorAll('[data-ig-link]').forEach(el => (el.href = c.instagramUrl));
  document.querySelectorAll('[data-wa-link]').forEach(el => (el.href = BP.waLink(c.whatsappNumero)));
  document.querySelectorAll('[data-brand-endereco]').forEach(el => (el.textContent = c.endereco));
  document.querySelectorAll('[data-brand-telefone]').forEach(el => (el.textContent = c.telefone));
}

function initHeader() {
  const header = document.querySelector('.site-header');
  if (!header) return;
  const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 30);
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });
}

function initMobileMenu() {
  const burger = document.querySelector('.burger');
  const menu = document.querySelector('.mobile-menu');
  if (!burger || !menu) return;
  const close = () => menu.classList.remove('open');
  burger.addEventListener('click', () => menu.classList.add('open'));
  menu.querySelector('.close-menu')?.addEventListener('click', close);
  menu.querySelectorAll('a').forEach(a => a.addEventListener('click', close));
}

function initReveal() {
  const items = document.querySelectorAll('.reveal');
  if (!items.length) return;
  const io = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  items.forEach(el => io.observe(el));
}

function initPetals() {
  const holder = document.querySelector('.petals');
  if (!holder) return;
  const count = window.innerWidth < 700 ? 8 : 16;
  for (let i = 0; i < count; i++) {
    const p = document.createElement('span');
    p.className = 'petal';
    const left = Math.random() * 100;
    const duration = 12 + Math.random() * 10;
    const delay = Math.random() * -20;
    const drift = (Math.random() * 160 - 80) + 'px';
    const scale = 0.6 + Math.random() * 0.8;
    p.style.left = left + '%';
    p.style.animationDuration = duration + 's';
    p.style.animationDelay = delay + 's';
    p.style.setProperty('--drift', drift);
    p.style.transform = `scale(${scale})`;
    holder.appendChild(p);
  }
}

function initVapor() {
  const wrap = document.querySelector('.vapor-wrap');
  if (!wrap) return;
  const count = window.innerWidth < 700 ? 5 : 9;
  for (let i = 0; i < count; i++) {
    const v = document.createElement('span');
    v.className = 'vapor';
    const left = 50 + (Math.random() * 30 - 15);
    const duration = 6 + Math.random() * 4;
    const delay = Math.random() * -8;
    v.style.left = left + '%';
    v.style.animationDuration = duration + 's';
    v.style.animationDelay = delay + 's';
    wrap.appendChild(v);
  }
}

/* ---------- Lupa de zoom (hover) ----------
   Uso: BP.attachZoom(imgElement) depois de qualquer imagem renderizada
   dinamicamente que deva ter lupa (imagem principal do produto). */
BP.attachZoom = function (img) {
  if (!img || img.dataset.zoomWired) return;
  img.dataset.zoomWired = '1';
  const holder = img.closest('.zoomable') || img.parentElement;
  if (!holder.classList.contains('zoomable')) holder.classList.add('zoomable');

  let lens = holder.querySelector('.zoom-lens');
  if (!lens) {
    lens = document.createElement('div');
    lens.className = 'zoom-lens';
    holder.appendChild(lens);
  }
  let hint = holder.querySelector('.zoom-hint');
  if (!hint) {
    hint = document.createElement('div');
    hint.className = 'zoom-hint';
    hint.innerHTML = '🔍 Toque para ampliar';
    holder.appendChild(hint);
  }

  const ZOOM = 2.4;
  holder.addEventListener('mousemove', (e) => {
    const rect = holder.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    lens.style.left = (x - lens.offsetWidth / 2) + 'px';
    lens.style.top = (y - lens.offsetHeight / 2) + 'px';
    lens.style.backgroundImage = `url("${img.currentSrc || img.src}")`;
    lens.style.backgroundSize = (rect.width * ZOOM) + 'px ' + (rect.height * ZOOM) + 'px';
    const bgX = -(x * ZOOM - lens.offsetWidth / 2);
    const bgY = -(y * ZOOM - lens.offsetHeight / 2);
    lens.style.backgroundPosition = `${bgX}px ${bgY}px`;
  });

  holder.addEventListener('click', () => BP.openLightbox(img.currentSrc || img.src));
};

/* ---------- Lightbox em tela cheia com zoom por scroll/pinça e arraste ---------- */
function initLightbox() {
  if (document.querySelector('.lightbox')) return;
  const box = document.createElement('div');
  box.className = 'lightbox';
  box.innerHTML = `
    <img id="lightbox-img" src="" alt="Perfume ampliado">
    <button class="lightbox-reset" id="lightbox-reset">Redefinir</button>
    <button class="lightbox-close" aria-label="Fechar">✕</button>
    <div class="lightbox-hint">Scroll ou pinça para ampliar · arraste para mover</div>
  `;
  document.body.appendChild(box);

  const imgEl = box.querySelector('#lightbox-img');
  let scale = 1, originX = 0, originY = 0, dragging = false, startX = 0, startY = 0;

  function apply() {
    imgEl.style.transform = `translate(${originX}px, ${originY}px) scale(${scale})`;
  }
  function reset() { scale = 1; originX = 0; originY = 0; apply(); }

  box.querySelector('.lightbox-close').addEventListener('click', () => { box.classList.remove('open'); reset(); });
  box.querySelector('#lightbox-reset').addEventListener('click', reset);
  box.addEventListener('click', (e) => { if (e.target === box) { box.classList.remove('open'); reset(); } });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { box.classList.remove('open'); reset(); } });

  box.addEventListener('wheel', (e) => {
    e.preventDefault();
    scale = Math.min(4, Math.max(1, scale - e.deltaY * 0.0018));
    apply();
  }, { passive: false });

  imgEl.addEventListener('mousedown', (e) => {
    dragging = true; imgEl.classList.add('dragging');
    startX = e.clientX - originX; startY = e.clientY - originY;
  });
  window.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    originX = e.clientX - startX; originY = e.clientY - startY;
    apply();
  });
  window.addEventListener('mouseup', () => { dragging = false; imgEl.classList.remove('dragging'); });

  // Pinça (touch) simples: dois dedos = zoom, um dedo = arraste
  let touchDist = null;
  box.addEventListener('touchstart', (e) => {
    if (e.touches.length === 2) {
      touchDist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
    } else if (e.touches.length === 1) {
      dragging = true;
      startX = e.touches[0].clientX - originX; startY = e.touches[0].clientY - originY;
    }
  }, { passive: true });
  box.addEventListener('touchmove', (e) => {
    if (e.touches.length === 2 && touchDist) {
      const dist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      scale = Math.min(4, Math.max(1, scale * (dist / touchDist)));
      touchDist = dist;
      apply();
    } else if (e.touches.length === 1 && dragging) {
      originX = e.touches[0].clientX - startX; originY = e.touches[0].clientY - startY;
      apply();
    }
  }, { passive: true });
  box.addEventListener('touchend', () => { dragging = false; touchDist = null; });

  BP.openLightbox = function (src) {
    imgEl.src = src;
    reset();
    box.classList.add('open');
  };
}

function initWhatsFloat() {
  const el = document.querySelector('.whats-float');
  if (!el || !BP.config) return;
  el.href = BP.waLink(BP.config.whatsappNumero);
}

/* Card de produto reutilizável entre home e catálogo */
function productCardHTML(p) {
  const tags = [];
  if (p.lancamento) tags.push('<span class="tag tag-new">Lançamento</span>');
  if (p.promocao) tags.push('<span class="tag tag-promo">Promoção</span>');
  if (p.destaque) tags.push('<span class="tag">Destaque</span>');

  return `
  <article class="card-product reveal">
    <div class="card-tags">${tags.join('')}</div>
    <a class="card-link" href="pages/produto.html?id=${encodeURIComponent(p.id)}" aria-label="${p.nome}"></a>
    <span class="spray-dot"></span><span class="spray-dot"></span><span class="spray-dot"></span>
    <span class="spray-dot"></span><span class="spray-dot"></span><span class="spray-dot"></span>
    <div class="card-media">
      <img src="${p.imagem}" alt="${p.nome}" loading="lazy">
      <div class="card-shine"></div>
    </div>
    <div class="card-brand">${p.marca}</div>
    <h3>${p.nome}</h3>
    <p class="card-desc">${p.descricaoCurta}</p>
    <div class="card-meta"><span>${p.volume}</span><span>${labelCategoria(p.categoria)}</span></div>
    <div class="card-actions" style="position:relative; z-index:2;">
      <a class="btn btn-insta btn-sm" target="_blank" rel="noopener" href="#" data-card-ig="${p.nome}">Instagram</a>
      <a class="btn btn-whats btn-sm" target="_blank" rel="noopener" href="#" data-card-wa="${p.nome}">WhatsApp</a>
    </div>
  </article>`;
}

function labelCategoria(cats) {
  const map = { masculino: 'Masculino', feminino: 'Feminino', unissex: 'Unissex', arabe: 'Árabe', importado: 'Importado' };
  const principal = cats.find(c => ['masculino', 'feminino', 'unissex'].includes(c));
  return principal ? map[principal] : (map[cats[0]] || '');
}

function wireCardButtons(root = document) {
  root.querySelectorAll('[data-card-wa]').forEach(a => {
    a.href = BP.waLink(BP.config.whatsappNumero, a.dataset.cardWa);
  });
  root.querySelectorAll('[data-card-ig]').forEach(a => {
    a.href = BP.igDmLink(BP.config?.instagramUsuario || '');
    a.addEventListener('click', (e) => {
      e.preventDefault();
      BP.igClick(BP.config.instagramUsuario, a.dataset.cardIg, a);
    });
  });
}

let toastTimeout = null;
function mostrarToast(referenciaEl, texto) {
  let toast = document.getElementById('bp-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'bp-toast';
    toast.style.cssText = 'position:fixed; left:50%; bottom:100px; transform:translateX(-50%) translateY(10px); background:#3E2B4A; color:#fff; padding:12px 22px; border-radius:999px; font-size:.82rem; z-index:600; opacity:0; transition:.35s ease; pointer-events:none; white-space:nowrap;';
    document.body.appendChild(toast);
  }
  toast.textContent = texto;
  clearTimeout(toastTimeout);
  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(-50%) translateY(0)';
  });
  toastTimeout = setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-50%) translateY(10px)';
  }, 2600);
}
