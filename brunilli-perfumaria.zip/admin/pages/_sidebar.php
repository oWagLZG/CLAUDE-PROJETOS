<?php
$paginaAtual = basename($_SERVER['SCRIPT_NAME']);
function navClass($nome, $atual) { return $nome === $atual ? 'active' : ''; }
?>
<aside class="admin-sidebar">
  <div class="brand">
    <img src="../assets/img/logo/logo.jpg" alt="Logo">
    <span>Brunilli</span>
  </div>
  <nav class="admin-nav">
    <a href="dashboard.php" class="<?= navClass('dashboard.php', $paginaAtual) ?>">Dashboard</a>
    <a href="produtos.php" class="<?= navClass('produtos.php', $paginaAtual) ?>">Produtos</a>
    <a href="configuracoes.php" class="<?= navClass('configuracoes.php', $paginaAtual) ?>">Configurações</a>
  </nav>
  <div class="sair">
    <div class="ver-site"><a href="../index.html" target="_blank">Ver site ↗</a></div>
    <a href="#" id="btn-sair">Sair do painel</a>
  </div>
</aside>
<script>
document.getElementById('btn-sair')?.addEventListener('click', async (e) => {
  e.preventDefault();
  await fetch('actions/logout.php', { method: 'POST' });
  window.location.href = 'index.php';
});
</script>
