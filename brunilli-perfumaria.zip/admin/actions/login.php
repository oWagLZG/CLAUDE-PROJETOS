<?php
require_once __DIR__ . '/../../includes/functions.php';
bp_start_session();
header('Content-Type: application/json; charset=utf-8');

// Limite simples de tentativas por sessão, para dificultar força bruta.
if (!isset($_SESSION['bp_tentativas'])) $_SESSION['bp_tentativas'] = 0;
if (!isset($_SESSION['bp_bloqueado_ate'])) $_SESSION['bp_bloqueado_ate'] = 0;

if (time() < $_SESSION['bp_bloqueado_ate']) {
    $restam = $_SESSION['bp_bloqueado_ate'] - time();
    bp_json_response(['ok' => false, 'erro' => "Muitas tentativas. Aguarde {$restam}s e tente novamente."]);
    exit;
}

$input = bp_input_json();
$senha = $input['senha'] ?? '';

$admin = bp_read_json(BP_ADMIN_JSON);
$hash = $admin['senhaAdminHash'] ?? '';

if ($senha !== '' && $hash !== '' && password_verify($senha, $hash)) {
    $_SESSION['bp_admin_logado'] = true;
    $_SESSION['bp_tentativas'] = 0;
    bp_json_response(['ok' => true]);
} else {
    $_SESSION['bp_tentativas']++;
    if ($_SESSION['bp_tentativas'] >= 5) {
        $_SESSION['bp_bloqueado_ate'] = time() + 60;
        $_SESSION['bp_tentativas'] = 0;
    }
    bp_json_response(['ok' => false, 'erro' => 'Senha incorreta.']);
}
