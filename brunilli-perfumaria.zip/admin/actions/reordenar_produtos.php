<?php
require_once __DIR__ . '/../../includes/functions.php';
bp_require_login();

$input = bp_input_json();
$ordemIds = $input['ordem'] ?? [];
if (!is_array($ordemIds) || !count($ordemIds)) {
    bp_json_response(['ok' => false, 'erro' => 'Lista de ordem inválida.']);
    exit;
}

$produtos = bp_read_json(BP_PRODUTOS_JSON);
$mapa = [];
foreach ($produtos as $p) $mapa[$p['id']] = $p;

$novaLista = [];
$posicao = 1;
foreach ($ordemIds as $id) {
    if (isset($mapa[$id])) {
        $mapa[$id]['ordem'] = $posicao++;
        $novaLista[] = $mapa[$id];
        unset($mapa[$id]);
    }
}
// qualquer produto que não veio na lista (edge case) vai para o fim, preservando dados
foreach ($mapa as $sobra) {
    $sobra['ordem'] = $posicao++;
    $novaLista[] = $sobra;
}

if (!bp_write_json(BP_PRODUTOS_JSON, $novaLista)) {
    bp_json_response(['ok' => false, 'erro' => 'Falha ao gravar a nova ordem.']);
    exit;
}

bp_json_response(['ok' => true]);
