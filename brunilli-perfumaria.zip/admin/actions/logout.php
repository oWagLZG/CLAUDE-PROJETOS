<?php
require_once __DIR__ . '/../../includes/functions.php';
bp_start_session();
$_SESSION = [];
session_destroy();
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true]);
