<?php
require_once __DIR__ . '/../../includes/functions.php';
bp_require_login();

$input = bp_input_json();
$id = trim($input['id'] ?? '');

$produtos = bp_read_json(BP_PRODUTOS_JSON);
$original = null;
foreach ($produtos as $p) {
    if ($p['id'] === $id) { $original = $p; break; }
}
if (!$original) {
    bp_json_response(['ok' => false, 'erro' => 'Produto não encontrado.']);
    exit;
}

$copia = $original;
$copia['nome'] = $original['nome'] . ' (cópia)';
$baseId = bp_slugify($copia['nome']);
$novoId = $baseId;
$sufixo = 2;
while (in_array($novoId, array_column($produtos, 'id'), true)) {
    $novoId = $baseId . '-' . $sufixo;
    $sufixo++;
}
$copia['id'] = $novoId;
$copia['destaque'] = false;
$maxOrdem = 0;
foreach ($produtos as $p) $maxOrdem = max($maxOrdem, $p['ordem'] ?? 0);
$copia['ordem'] = $maxOrdem + 1;

$produtos[] = $copia;

if (!bp_write_json(BP_PRODUTOS_JSON, $produtos)) {
    bp_json_response(['ok' => false, 'erro' => 'Falha ao gravar o arquivo de produtos.']);
    exit;
}

bp_json_response(['ok' => true, 'produto' => $copia]);
