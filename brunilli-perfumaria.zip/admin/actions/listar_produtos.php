<?php
require_once __DIR__ . '/../../includes/functions.php';
bp_require_login();
$produtos = bp_read_json(BP_PRODUTOS_JSON);
usort($produtos, fn($a, $b) => ($a['ordem'] ?? 0) <=> ($b['ordem'] ?? 0));
bp_json_response(['ok' => true, 'produtos' => $produtos]);
