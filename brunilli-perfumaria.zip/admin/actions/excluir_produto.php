<?php
require_once __DIR__ . '/../../includes/functions.php';
bp_require_login();

$input = bp_input_json();
$id = trim($input['id'] ?? '');
if ($id === '') {
    bp_json_response(['ok' => false, 'erro' => 'ID do produto não informado.']);
    exit;
}

$produtos = bp_read_json(BP_PRODUTOS_JSON);
$restantes = array_values(array_filter($produtos, fn($p) => $p['id'] !== $id));

if (count($restantes) === count($produtos)) {
    bp_json_response(['ok' => false, 'erro' => 'Produto não encontrado.']);
    exit;
}

if (!bp_write_json(BP_PRODUTOS_JSON, $restantes)) {
    bp_json_response(['ok' => false, 'erro' => 'Falha ao gravar o arquivo de produtos.']);
    exit;
}

bp_json_response(['ok' => true]);
