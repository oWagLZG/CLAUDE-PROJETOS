<?php
require_once __DIR__ . '/../../includes/functions.php';
bp_require_login();
$config = bp_read_json(BP_CONFIG_JSON);
bp_json_response(['ok' => true, 'config' => $config]);
