<?php
require_once __DIR__ . '/../../includes/functions.php';
bp_require_login();

$config = bp_read_json(BP_CONFIG_JSON);

$config['nomeLoja'] = trim($_POST['nomeLoja'] ?? $config['nomeLoja'] ?? '');
$config['slogan'] = trim($_POST['slogan'] ?? $config['slogan'] ?? '');
$config['textoInstitucional'] = trim($_POST['textoInstitucional'] ?? $config['textoInstitucional'] ?? '');
$config['instagramUsuario'] = ltrim(trim($_POST['instagramUsuario'] ?? $config['instagramUsuario'] ?? ''), '@');
$config['instagramUrl'] = 'https://instagram.com/' . $config['instagramUsuario'];
$config['telefone'] = trim($_POST['telefone'] ?? $config['telefone'] ?? '');
$config['endereco'] = trim($_POST['endereco'] ?? $config['endereco'] ?? '');

$whatsappNumero = preg_replace('/\D+/', '', $_POST['whatsappNumero'] ?? '');
if ($whatsappNumero !== '') {
    $config['whatsappNumero'] = $whatsappNumero;
    $config['redesSociais']['whatsapp'] = 'https://wa.me/' . $whatsappNumero;
}
$config['redesSociais']['instagram'] = $config['instagramUrl'];
if (isset($_POST['tiktok'])) {
    $config['redesSociais']['tiktok'] = trim($_POST['tiktok']);
}

// Upload de logo (opcional)
if (!empty($_FILES['logo']['name'])) {
    $up = bp_handle_upload_generico('logo', 'logo', BP_ROOT . '/assets/img/logo', 'assets/img/logo');
    if ($up['ok']) $config['logo'] = $up['caminho'];
}
// Upload de banner (opcional)
if (!empty($_FILES['banner']['name'])) {
    $up = bp_handle_upload_generico('banner', 'banner', BP_ROOT . '/assets/img/produtos', 'assets/img/produtos');
    if ($up['ok']) $config['banner'] = $up['caminho'];
}

if (!bp_write_json(BP_CONFIG_JSON, $config)) {
    bp_json_response(['ok' => false, 'erro' => 'Falha ao gravar configurações.']);
    exit;
}

// Troca de senha (opcional, campo separado por segurança)
$respostaSenha = null;
if (!empty($_POST['novaSenha'])) {
    $novaSenha = $_POST['novaSenha'];
    if (strlen($novaSenha) < 6) {
        $respostaSenha = 'A nova senha deve ter pelo menos 6 caracteres.';
    } else {
        $admin = bp_read_json(BP_ADMIN_JSON);
        $admin['senhaAdminHash'] = password_hash($novaSenha, PASSWORD_DEFAULT);
        bp_write_json(BP_ADMIN_JSON, $admin);
    }
}

bp_json_response(['ok' => true, 'config' => $config, 'avisoSenha' => $respostaSenha]);

/**
 * Upload genérico para logo/banner (fora da pasta de produtos).
 */
function bp_handle_upload_generico($campo, $prefixo, $dirDestino, $caminhoPublico) {
    if (empty($_FILES[$campo]) || $_FILES[$campo]['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'erro' => 'Falha no envio da imagem.'];
    }
    $file = $_FILES[$campo];
    if ($file['size'] > 5 * 1024 * 1024) {
        return ['ok' => false, 'erro' => 'Imagem maior que 5MB.'];
    }
    $permitidos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $tipoReal = mime_content_type($file['tmp_name']);
    if (!isset($permitidos[$tipoReal])) {
        return ['ok' => false, 'erro' => 'Formato não permitido.'];
    }
    $ext = $permitidos[$tipoReal];
    $nomeArquivo = bp_slugify($prefixo) . '-' . substr(md5(uniqid('', true)), 0, 6) . '.' . $ext;
    if (!is_dir($dirDestino)) mkdir($dirDestino, 0755, true);
    $destino = $dirDestino . '/' . $nomeArquivo;
    if (!move_uploaded_file($file['tmp_name'], $destino)) {
        return ['ok' => false, 'erro' => 'Não foi possível salvar a imagem.'];
    }
    return ['ok' => true, 'caminho' => $caminhoPublico . '/' . $nomeArquivo];
}
