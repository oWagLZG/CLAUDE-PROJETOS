<?php
require_once __DIR__ . '/../../includes/functions.php';
bp_require_login();

$nome = trim($_POST['nome'] ?? '');
if ($nome === '') {
    bp_json_response(['ok' => false, 'erro' => 'O nome do perfume é obrigatório.']);
    exit;
}

$produtos = bp_read_json(BP_PRODUTOS_JSON);
$idOriginal = trim($_POST['idOriginal'] ?? '');
$eEdicao = $idOriginal !== '';

// Gera um id/slug único a partir do nome (usado na URL do produto).
$idNovo = bp_slugify($nome);
$idFinal = $idNovo;
$sufixo = 2;
while (true) {
    $conflito = false;
    foreach ($produtos as $p) {
        if ($p['id'] === $idFinal && $p['id'] !== $idOriginal) { $conflito = true; break; }
    }
    if (!$conflito) break;
    $idFinal = $idNovo . '-' . $sufixo;
    $sufixo++;
}

$categorias = $_POST['categoria'] ?? [];
if (!is_array($categorias)) $categorias = [$categorias];
$categorias = array_values(array_filter(array_map('trim', $categorias)));

$imagemFinal = trim($_POST['imagemAtual'] ?? '');
if (!empty($_FILES['imagem']['name'])) {
    $up = bp_handle_upload('imagem', $idFinal);
    if (!$up['ok']) {
        bp_json_response(['ok' => false, 'erro' => $up['erro']]);
        exit;
    }
    $imagemFinal = $up['caminho'];
}
if ($imagemFinal === '') {
    bp_json_response(['ok' => false, 'erro' => 'Envie uma imagem para o produto.']);
    exit;
}

$novoProduto = [
    'id' => $idFinal,
    'nome' => $nome,
    'marca' => trim($_POST['marca'] ?? ''),
    'categoria' => $categorias,
    'destaque' => isset($_POST['destaque']),
    'lancamento' => isset($_POST['lancamento']),
    'promocao' => isset($_POST['promocao']),
    'descricaoCurta' => trim($_POST['descricaoCurta'] ?? ''),
    'descricaoLonga' => trim($_POST['descricaoLonga'] ?? ''),
    'volume' => trim($_POST['volume'] ?? ''),
    'preco' => ($_POST['preco'] ?? '') !== '' ? floatval(str_replace(',', '.', $_POST['preco'])) : null,
    'imagem' => $imagemFinal,
    'galeria' => [$imagemFinal],
    'familiaOlfativa' => trim($_POST['familiaOlfativa'] ?? '') ?: 'A confirmar',
    'notasTopo' => trim($_POST['notasTopo'] ?? '') ?: 'A confirmar',
    'notasCoracao' => trim($_POST['notasCoracao'] ?? '') ?: 'A confirmar',
    'notasFundo' => trim($_POST['notasFundo'] ?? '') ?: 'A confirmar',
    'fixacao' => trim($_POST['fixacao'] ?? '') ?: 'A confirmar',
    'projecao' => trim($_POST['projecao'] ?? '') ?: 'A confirmar',
    'ocasiao' => trim($_POST['ocasiao'] ?? '') ?: 'A confirmar',
    'estacao' => trim($_POST['estacao'] ?? '') ?: 'A confirmar',
];

if ($eEdicao) {
    $encontrado = false;
    foreach ($produtos as $i => $p) {
        if ($p['id'] === $idOriginal) {
            // preserva galeria com mais de uma imagem e a ordem, se já existiam
            $novoProduto['galeria'] = (!empty($_FILES['imagem']['name']))
                ? [$imagemFinal]
                : ($p['galeria'] ?? [$imagemFinal]);
            $novoProduto['ordem'] = $p['ordem'] ?? (count($produtos) + 1);
            $produtos[$i] = $novoProduto;
            $encontrado = true;
            break;
        }
    }
    if (!$encontrado) {
        bp_json_response(['ok' => false, 'erro' => 'Produto original não encontrado para edição.']);
        exit;
    }
} else {
    $maxOrdem = 0;
    foreach ($produtos as $p) $maxOrdem = max($maxOrdem, $p['ordem'] ?? 0);
    $novoProduto['ordem'] = $maxOrdem + 1;
    $produtos[] = $novoProduto;
}

if (!bp_write_json(BP_PRODUTOS_JSON, $produtos)) {
    bp_json_response(['ok' => false, 'erro' => 'Falha ao gravar o arquivo de produtos no servidor.']);
    exit;
}

bp_json_response(['ok' => true, 'produto' => $novoProduto]);
