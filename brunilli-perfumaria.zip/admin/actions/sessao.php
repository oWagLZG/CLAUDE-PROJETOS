<?php
require_once __DIR__ . '/../../includes/functions.php';
bp_start_session();
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['logado' => !empty($_SESSION['bp_admin_logado'])]);
