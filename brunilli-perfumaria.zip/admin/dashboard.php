<?php
require_once __DIR__ . '/../includes/functions.php';
bp_start_session();
if (empty($_SESSION['bp_admin_logado'])) { header('Location: index.php'); exit; }
$produtos = bp_read_json(BP_PRODUTOS_JSON);
$total = count($produtos);
$destaques = count(array_filter($produtos, fn($p) => !empty($p['destaque'])));
$lancamentos = count(array_filter($produtos, fn($p) => !empty($p['lancamento'])));
$promocoes = count(array_filter($produtos, fn($p) => !empty($p['promocao'])));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — Painel Brunilli</title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="../assets/img/logo/logo.jpg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/admin.css">
</head>
<body>
<div class="admin-shell">
  <?php include __DIR__ . '/pages/_sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar">
      <h1>Olá! 👋</h1>
      <a href="../index.html" target="_blank" class="btn-admin btn-admin-ghost">Ver site</a>
    </div>

    <div class="kpi-grid">
      <div class="kpi"><strong><?= $total ?></strong><span>Perfumes cadastrados</span></div>
      <div class="kpi"><strong><?= $destaques ?></strong><span>Em destaque</span></div>
      <div class="kpi"><strong><?= $lancamentos ?></strong><span>Lançamentos</span></div>
      <div class="kpi"><strong><?= $promocoes ?></strong><span>Em promoção</span></div>
    </div>

    <div class="admin-card">
      <h3>Bem-vinda ao painel da Brunilli Perfumaria</h3>
      <p style="color:var(--ink-soft); line-height:1.7; max-width:640px;">
        Aqui você cadastra, edita e organiza os perfumes que aparecem no site, além de
        atualizar WhatsApp, Instagram, textos e imagens institucionais — tudo sem precisar
        mexer em código. Comece por <strong>Produtos</strong> para cadastrar o catálogo, e use
        <strong>Configurações</strong> para ajustar os dados de contato da loja.
      </p>
      <div style="display:flex; gap:12px; margin-top:20px;">
        <a href="produtos.php" class="btn-admin btn-admin-primary">Gerenciar produtos</a>
        <a href="configuracoes.php" class="btn-admin btn-admin-ghost">Configurações da loja</a>
      </div>
    </div>
  </main>
</div>
</body>
</html>
