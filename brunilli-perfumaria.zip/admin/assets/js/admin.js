/* =========================================================
   BRUNILLI PERFUMARIA — admin.js
   ========================================================= */

let PRODUTOS = [];
let arquivoImagemSelecionado = false;

async function carregarProdutos() {
  const res = await fetch('actions/listar_produtos.php');
  if (res.status === 401) { window.location.href = 'index.php'; return; }
  const data = await res.json();
  PRODUTOS = data.produtos || [];
  renderTabela();
}

function labelCategorias(cats) {
  const map = { masculino: 'Masculino', feminino: 'Feminino', unissex: 'Unissex', arabe: 'Árabe', importado: 'Importado' };
  return (cats || []).map(c => map[c] || c).join(', ');
}

function renderTabela() {
  const termo = (document.getElementById('busca-admin')?.value || '').toLowerCase();
  const tbody = document.getElementById('tbody-produtos');
  const vazio = document.getElementById('tabela-vazia');
  if (!tbody) return;

  let lista = [...PRODUTOS].sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
  if (termo) {
    lista = lista.filter(p =>
      p.nome.toLowerCase().includes(termo) ||
      (p.marca || '').toLowerCase().includes(termo) ||
      labelCategorias(p.categoria).toLowerCase().includes(termo)
    );
  }

  if (!lista.length) {
    tbody.innerHTML = '';
    vazio.style.display = 'block';
    return;
  }
  vazio.style.display = 'none';

  tbody.innerHTML = lista.map(p => `
    <tr draggable="true" data-id="${p.id}">
      <td style="cursor:grab; color:var(--ink-soft);">⠿</td>
      <td>
        <div class="prod-nome">
          <img class="prod-thumb" src="../${p.imagem}" alt="${p.nome}">
          <span>${p.nome}</span>
        </div>
      </td>
      <td>${p.marca || '—'}</td>
      <td>${labelCategorias(p.categoria) || '—'}</td>
      <td>${p.volume || '—'}</td>
      <td>
        ${p.destaque ? '<span class="badge">Destaque</span>' : ''}
        ${p.lancamento ? '<span class="badge badge-new">Lançamento</span>' : ''}
        ${p.promocao ? '<span class="badge badge-promo">Promoção</span>' : ''}
      </td>
      <td>
        <div class="row-actions">
          <button class="btn-admin btn-admin-ghost btn-admin-sm" data-editar="${p.id}">Editar</button>
          <button class="btn-admin btn-admin-ghost btn-admin-sm" data-duplicar="${p.id}">Duplicar</button>
          <button class="btn-admin btn-admin-danger btn-admin-sm" data-excluir="${p.id}">Excluir</button>
        </div>
      </td>
    </tr>
  `).join('');

  wireLinhasTabela();
  wireDragAndDrop();
}

function wireLinhasTabela() {
  document.querySelectorAll('[data-editar]').forEach(btn => {
    btn.addEventListener('click', () => abrirDrawer(btn.dataset.editar));
  });
  document.querySelectorAll('[data-duplicar]').forEach(btn => {
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      const res = await fetch('actions/duplicar_produto.php', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: btn.dataset.duplicar })
      });
      const data = await res.json();
      if (data.ok) carregarProdutos();
      else alert(data.erro || 'Erro ao duplicar.');
      btn.disabled = false;
    });
  });
  document.querySelectorAll('[data-excluir]').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('Excluir este perfume? Esta ação não pode ser desfeita.')) return;
      const res = await fetch('actions/excluir_produto.php', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: btn.dataset.excluir })
      });
      const data = await res.json();
      if (data.ok) carregarProdutos();
      else alert(data.erro || 'Erro ao excluir.');
    });
  });
}

/* ---------- Drag and drop de reordenação ---------- */
function wireDragAndDrop() {
  const tbody = document.getElementById('tbody-produtos');
  let linhaArrastada = null;

  tbody.querySelectorAll('tr').forEach(tr => {
    tr.addEventListener('dragstart', () => { linhaArrastada = tr; tr.classList.add('dragging'); });
    tr.addEventListener('dragend', async () => {
      tr.classList.remove('dragging');
      const ordem = [...tbody.querySelectorAll('tr')].map(r => r.dataset.id);
      await fetch('actions/reordenar_produtos.php', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ordem })
      });
    });
    tr.addEventListener('dragover', (e) => {
      e.preventDefault();
      const alvo = tr;
      if (!linhaArrastada || alvo === linhaArrastada) return;
      const rect = alvo.getBoundingClientRect();
      const depois = (e.clientY - rect.top) > rect.height / 2;
      alvo.parentNode.insertBefore(linhaArrastada, depois ? alvo.nextSibling : alvo);
    });
  });
}

/* ---------- Drawer (form) ---------- */
function abrirDrawer(id) {
  const form = document.getElementById('form-produto');
  form.reset();
  document.getElementById('form-msg').textContent = '';
  document.getElementById('upload-preview').style.display = 'none';
  document.getElementById('upload-texto').style.display = 'block';
  arquivoImagemSelecionado = false;

  const p = id ? PRODUTOS.find(x => x.id === id) : null;
  document.getElementById('drawer-titulo').textContent = p ? 'Editar produto' : 'Novo produto';
  document.getElementById('idOriginal').value = p ? p.id : '';
  document.getElementById('imagemAtual').value = p ? p.imagem : '';

  if (p) {
    document.getElementById('nome').value = p.nome || '';
    document.getElementById('marca').value = p.marca || '';
    document.getElementById('descricaoCurta').value = p.descricaoCurta || '';
    document.getElementById('descricaoLonga').value = p.descricaoLonga || '';
    document.getElementById('volume').value = p.volume || '';
    document.getElementById('preco').value = p.preco ?? '';
    document.getElementById('destaque').checked = !!p.destaque;
    document.getElementById('lancamento').checked = !!p.lancamento;
    document.getElementById('promocao').checked = !!p.promocao;
    document.getElementById('familiaOlfativa').value = valorOuVazio(p.familiaOlfativa);
    document.getElementById('fixacao').value = valorOuVazio(p.fixacao);
    document.getElementById('notasTopo').value = valorOuVazio(p.notasTopo);
    document.getElementById('notasCoracao').value = valorOuVazio(p.notasCoracao);
    document.getElementById('notasFundo').value = valorOuVazio(p.notasFundo);
    document.getElementById('projecao').value = valorOuVazio(p.projecao);
    document.getElementById('ocasiao').value = valorOuVazio(p.ocasiao);
    document.getElementById('estacao').value = valorOuVazio(p.estacao);
    (p.categoria || []).forEach(c => {
      const cb = form.querySelector(`input[name="categoria[]"][value="${c}"]`);
      if (cb) cb.checked = true;
    });
    if (p.imagem) {
      const preview = document.getElementById('upload-preview');
      preview.src = '../' + p.imagem;
      preview.style.display = 'block';
      document.getElementById('upload-texto').style.display = 'none';
    }
  }

  document.getElementById('overlay-form').classList.add('open');
}

function valorOuVazio(v) { return (v && v !== 'A confirmar') ? v : ''; }

function fecharDrawer() {
  document.getElementById('overlay-form').classList.remove('open');
}

document.addEventListener('DOMContentLoaded', () => {
  carregarProdutos();

  document.getElementById('btn-novo')?.addEventListener('click', () => abrirDrawer(null));
  document.getElementById('btn-fechar-drawer')?.addEventListener('click', fecharDrawer);
  document.getElementById('overlay-form')?.addEventListener('click', (e) => {
    if (e.target.id === 'overlay-form') fecharDrawer();
  });
  document.getElementById('busca-admin')?.addEventListener('input', renderTabela);

  document.getElementById('upload-box')?.addEventListener('click', () => {
    document.getElementById('input-imagem').click();
  });
  document.getElementById('input-imagem')?.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    arquivoImagemSelecionado = true;
    const preview = document.getElementById('upload-preview');
    preview.src = URL.createObjectURL(file);
    preview.style.display = 'block';
    document.getElementById('upload-texto').style.display = 'none';
  });

  document.getElementById('form-produto')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const msg = document.getElementById('form-msg');
    const btn = document.getElementById('btn-salvar');
    msg.className = 'form-msg';
    msg.textContent = '';

    if (!arquivoImagemSelecionado && !document.getElementById('imagemAtual').value) {
      msg.textContent = 'Envie uma imagem para o produto.';
      msg.className = 'form-msg erro';
      return;
    }

    btn.disabled = true; btn.textContent = 'Salvando...';
    try {
      const fd = new FormData(form);
      const res = await fetch('actions/salvar_produto.php', { method: 'POST', body: fd });
      const data = await res.json();
      if (data.ok) {
        msg.textContent = 'Produto salvo com sucesso.';
        msg.className = 'form-msg ok';
        await carregarProdutos();
        setTimeout(fecharDrawer, 500);
      } else {
        msg.textContent = data.erro || 'Erro ao salvar produto.';
        msg.className = 'form-msg erro';
      }
    } catch (err) {
      msg.textContent = 'Erro de conexão com o servidor.';
      msg.className = 'form-msg erro';
    }
    btn.disabled = false; btn.textContent = 'Salvar produto';
  });
});
