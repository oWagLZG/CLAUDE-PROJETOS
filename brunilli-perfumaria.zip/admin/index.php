<?php
require_once __DIR__ . '/../includes/functions.php';
bp_start_session();
if (!empty($_SESSION['bp_admin_logado'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Painel — Brunilli Perfumaria</title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="../assets/img/logo/logo.jpg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/admin.css">
</head>
<body class="login-body">
  <div class="login-card">
    <img src="../assets/img/logo/logo.jpg" alt="Logo" class="login-logo">
    <h1>Painel Brunilli</h1>
    <p class="login-sub">Acesso restrito à administração da loja.</p>
    <form id="form-login">
      <label for="senha">Senha</label>
      <input type="password" id="senha" name="senha" autocomplete="current-password" required>
      <div id="login-erro" class="login-erro"></div>
      <button type="submit" class="btn-admin btn-admin-primary btn-block">Entrar</button>
    </form>
  </div>
  <script>
    document.getElementById('form-login').addEventListener('submit', async (e) => {
      e.preventDefault();
      const senha = document.getElementById('senha').value;
      const erro = document.getElementById('login-erro');
      erro.textContent = '';
      try {
        const res = await fetch('actions/login.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ senha })
        });
        const data = await res.json();
        if (data.ok) {
          window.location.href = 'dashboard.php';
        } else {
          erro.textContent = data.erro || 'Não foi possível entrar.';
        }
      } catch (err) {
        erro.textContent = 'Erro de conexão com o servidor.';
      }
    });
  </script>
</body>
</html>
