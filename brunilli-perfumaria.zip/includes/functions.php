<?php
/**
 * Brunilli Perfumaria — funções compartilhadas do painel administrativo.
 * Este arquivo NUNCA deve ser acessado diretamente pela URL (ver .htaccess
 * desta pasta); ele é incluído pelos scripts em /admin/actions/.
 */

define('BP_ROOT', dirname(__DIR__));
define('BP_PRODUTOS_JSON', BP_ROOT . '/database/produtos.json');
define('BP_CONFIG_JSON', BP_ROOT . '/config/config.json');
define('BP_ADMIN_JSON', BP_ROOT . '/config/admin.json');
define('BP_UPLOADS_DIR', BP_ROOT . '/assets/img/produtos');

function bp_start_session() {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
}

function bp_require_login() {
    bp_start_session();
    if (empty($_SESSION['bp_admin_logado'])) {
        http_response_code(401);
        bp_json_response(['ok' => false, 'erro' => 'Sessão expirada. Faça login novamente.']);
        exit;
    }
}

function bp_json_response($data) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

function bp_read_json($path) {
    if (!file_exists($path)) return [];
    $raw = file_get_contents($path);
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/**
 * Grava JSON de forma segura: escreve em arquivo temporário e troca via
 * rename() (operação atômica), evitando que um JSON corrompido fique salvo
 * caso duas pessoas mexam no painel ao mesmo tempo ou a gravação falhe no meio.
 * Usa lock exclusivo (flock) para evitar escrita concorrente.
 */
function bp_write_json($path, $data) {
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($json === false) return false;

    $lockFile = $path . '.lock';
    $fp = fopen($lockFile, 'c');
    if (!$fp) return false;
    flock($fp, LOCK_EX);

    $tmp = $path . '.tmp';
    $ok = file_put_contents($tmp, $json) !== false;
    if ($ok) {
        $ok = rename($tmp, $path);
    }

    flock($fp, LOCK_UN);
    fclose($fp);
    return $ok;
}

function bp_slugify($texto) {
    $texto = trim($texto);
    $texto = iconv('UTF-8', 'ASCII//TRANSLIT', $texto);
    $texto = strtolower($texto);
    $texto = preg_replace('/[^a-z0-9]+/', '-', $texto);
    return trim($texto, '-');
}

function bp_input_json() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/**
 * Valida e move um upload de imagem para /assets/img/produtos.
 * Só aceita jpg/jpeg/png/webp, checa o tipo real do arquivo (não confia na
 * extensão enviada pelo navegador) e limita o tamanho a 5MB.
 */
function bp_handle_upload($fileField, $slugBase) {
    if (empty($_FILES[$fileField]) || $_FILES[$fileField]['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'erro' => 'Nenhuma imagem enviada ou houve falha no envio.'];
    }
    $file = $_FILES[$fileField];

    if ($file['size'] > 5 * 1024 * 1024) {
        return ['ok' => false, 'erro' => 'Imagem maior que 5MB.'];
    }

    $permitidos = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
    ];
    $tipoReal = mime_content_type($file['tmp_name']);
    if (!isset($permitidos[$tipoReal])) {
        return ['ok' => false, 'erro' => 'Formato de imagem não permitido. Use JPG, PNG ou WEBP.'];
    }

    $ext = $permitidos[$tipoReal];
    $nomeArquivo = bp_slugify($slugBase) . '-' . substr(md5(uniqid('', true)), 0, 6) . '.' . $ext;
    $destino = BP_UPLOADS_DIR . '/' . $nomeArquivo;

    if (!is_dir(BP_UPLOADS_DIR)) {
        mkdir(BP_UPLOADS_DIR, 0755, true);
    }
    if (!move_uploaded_file($file['tmp_name'], $destino)) {
        return ['ok' => false, 'erro' => 'Não foi possível salvar a imagem no servidor.'];
    }

    return ['ok' => true, 'caminho' => 'assets/img/produtos/' . $nomeArquivo];
}
