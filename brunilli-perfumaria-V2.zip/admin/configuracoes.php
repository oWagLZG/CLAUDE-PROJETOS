<?php
require_once __DIR__ . '/../includes/functions.php';
bp_start_session();
if (empty($_SESSION['bp_admin_logado'])) { header('Location: index.php'); exit; }
$config = bp_read_json(BP_CONFIG_JSON);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Configurações — Painel Brunilli</title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="../assets/img/logo/logo.jpg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/admin.css?v=20260806a">
</head>
<body>
<div class="admin-shell">
  <?php include __DIR__ . '/pages/_sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar"><h1>Configurações</h1></div>

    <form id="form-config">
      <div class="admin-card">
        <h3>Identidade da loja</h3>
        <div class="field"><label>Nome da loja</label><input type="text" name="nomeLoja" value="<?= htmlspecialchars($config['nomeLoja'] ?? '') ?>"></div>
        <div class="field"><label>Slogan</label><input type="text" name="slogan" value="<?= htmlspecialchars($config['slogan'] ?? '') ?>"></div>
        <div class="field"><label>Texto institucional (seção "Sobre")</label><textarea name="textoInstitucional" style="min-height:120px;"><?= htmlspecialchars($config['textoInstitucional'] ?? '') ?></textarea></div>

        <div class="field-row">
          <div class="field">
            <label>Logo atual</label>
            <img src="../<?= htmlspecialchars($config['logo'] ?? '') ?>" style="width:80px;height:80px;border-radius:50%;object-fit:cover;margin-bottom:8px;">
            <input type="file" name="logo" accept="image/jpeg,image/png,image/webp">
          </div>
          <div class="field">
            <label>Banner atual (imagem da home)</label>
            <img src="../<?= htmlspecialchars($config['banner'] ?? '') ?>" style="width:140px;height:80px;border-radius:10px;object-fit:cover;margin-bottom:8px;">
            <input type="file" name="banner" accept="image/jpeg,image/png,image/webp">
          </div>
        </div>
      </div>

      <div class="admin-card">
        <h3>Contato e redes sociais</h3>
        <div class="field-row">
          <div class="field"><label>Usuário do Instagram (sem @)</label><input type="text" name="instagramUsuario" value="<?= htmlspecialchars($config['instagramUsuario'] ?? '') ?>"></div>
          <div class="field"><label>WhatsApp (com DDI e DDD, só números)</label><input type="text" name="whatsappNumero" value="<?= htmlspecialchars($config['whatsappNumero'] ?? '') ?>" placeholder="Ex: 5511999998888"></div>
        </div>
        <div class="field-row">
          <div class="field"><label>Telefone (exibição)</label><input type="text" name="telefone" value="<?= htmlspecialchars($config['telefone'] ?? '') ?>"></div>
          <div class="field"><label>Endereço</label><input type="text" name="endereco" value="<?= htmlspecialchars($config['endereco'] ?? '') ?>"></div>
        </div>
      </div>

      <div class="admin-card">
        <h3>Segurança</h3>
        <div class="field">
          <label>Trocar senha do painel (deixe em branco para manter a atual)</label>
          <input type="password" name="novaSenha" placeholder="Nova senha (mínimo 6 caracteres)">
        </div>
      </div>

      <div id="config-msg" class="form-msg"></div>
      <button type="submit" class="btn-admin btn-admin-primary" id="btn-salvar-config">Salvar configurações</button>
    </form>
  </main>
</div>

<script>
document.getElementById('form-config').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('config-msg');
  const btn = document.getElementById('btn-salvar-config');
  btn.disabled = true; btn.textContent = 'Salvando...';
  msg.className = 'form-msg'; msg.textContent = '';
  try {
    const fd = new FormData(e.target);
    const res = await fetch('actions/salvar_config.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.ok) {
      msg.textContent = data.avisoSenha ? data.avisoSenha : 'Configurações salvas com sucesso.';
      msg.className = 'form-msg ' + (data.avisoSenha ? 'erro' : 'ok');
    } else {
      msg.textContent = data.erro || 'Erro ao salvar.';
      msg.className = 'form-msg erro';
    }
  } catch (err) {
    msg.textContent = 'Erro de conexão com o servidor.';
    msg.className = 'form-msg erro';
  }
  btn.disabled = false; btn.textContent = 'Salvar configurações';
});
</script>
</body>
</html>
