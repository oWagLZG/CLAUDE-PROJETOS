<?php
require_once __DIR__ . '/../includes/functions.php';
bp_start_session();
if (empty($_SESSION['bp_admin_logado'])) { header('Location: index.php'); exit; }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Produtos — Painel Brunilli</title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="../assets/img/logo/logo.jpg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/admin.css?v=20260806a">
</head>
<body>
<div class="admin-shell">
  <?php include __DIR__ . '/pages/_sidebar.php'; ?>
  <main class="admin-main">
    <div class="admin-topbar">
      <h1>Produtos</h1>
      <button class="btn-admin btn-admin-primary" id="btn-novo">+ Novo produto</button>
    </div>

    <div class="admin-card">
      <div class="toolbar-row">
        <div class="toolbar-search">
          <input type="text" id="busca-admin" placeholder="Buscar por nome, marca ou categoria...">
        </div>
        <span style="font-size:.78rem; color:var(--ink-soft);">Arraste as linhas pela primeira coluna para reordenar no site.</span>
      </div>

      <table class="table-produtos">
        <thead>
          <tr>
            <th></th>
            <th>Produto</th>
            <th>Marca</th>
            <th>Categoria</th>
            <th>Volume</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody id="tbody-produtos"></tbody>
      </table>
      <div id="tabela-vazia" style="display:none; padding:40px; text-align:center; color:var(--ink-soft);">Nenhum produto cadastrado ainda.</div>
    </div>
  </main>
</div>

<!-- DRAWER: cadastro/edição -->
<div class="overlay" id="overlay-form">
  <div class="drawer">
    <div class="drawer-head">
      <h2 id="drawer-titulo">Novo produto</h2>
      <button class="btn-admin icon-only btn-admin-ghost" id="btn-fechar-drawer">✕</button>
    </div>

    <form id="form-produto">
      <input type="hidden" name="idOriginal" id="idOriginal">
      <input type="hidden" name="imagemAtual" id="imagemAtual">

      <div class="field">
        <label>Imagem do produto</label>
        <div class="upload-box" id="upload-box">
          <span id="upload-texto">Clique para enviar uma imagem (JPG, PNG ou WEBP, até 5MB)</span>
          <img id="upload-preview" class="upload-preview" style="display:none;">
        </div>
        <input type="file" name="imagem" id="input-imagem" accept="image/jpeg,image/png,image/webp" style="display:none;">
      </div>

      <div class="field-row">
        <div class="field">
          <label>Nome do perfume *</label>
          <input type="text" name="nome" id="nome" required>
        </div>
        <div class="field">
          <label>Marca</label>
          <input type="text" name="marca" id="marca">
        </div>
      </div>

      <div class="field">
        <label>Categoria</label>
        <div class="checks">
          <label class="check-pill"><input type="checkbox" name="categoria[]" value="masculino"> Masculino</label>
          <label class="check-pill"><input type="checkbox" name="categoria[]" value="feminino"> Feminino</label>
          <label class="check-pill"><input type="checkbox" name="categoria[]" value="unissex"> Unissex</label>
          <label class="check-pill"><input type="checkbox" name="categoria[]" value="arabe"> Árabe</label>
          <label class="check-pill"><input type="checkbox" name="categoria[]" value="importado"> Importado</label>
        </div>
      </div>

      <div class="field">
        <label>Descrição curta (aparece nos cards)</label>
        <textarea name="descricaoCurta" id="descricaoCurta" maxlength="140"></textarea>
      </div>
      <div class="field">
        <label>Descrição completa (aparece na página do produto)</label>
        <textarea name="descricaoLonga" id="descricaoLonga"></textarea>
      </div>

      <div class="field-row">
        <div class="field">
          <label>Volume</label>
          <input type="text" name="volume" id="volume" placeholder="Ex: 100ml">
        </div>
        <div class="field">
          <label>Preço (opcional)</label>
          <input type="number" step="0.01" name="preco" id="preco" placeholder="Ex: 189.90">
        </div>
      </div>

      <div class="field">
        <label>Destaques</label>
        <div class="checks">
          <label class="check-pill"><input type="checkbox" name="destaque" id="destaque"> Destaque</label>
          <label class="check-pill"><input type="checkbox" name="lancamento" id="lancamento"> Lançamento</label>
          <label class="check-pill"><input type="checkbox" name="promocao" id="promocao"> Promoção</label>
        </div>
      </div>

      <div class="section-title">Ficha olfativa</div>
      <div class="field-row">
        <div class="field"><label>Família olfativa</label><input type="text" name="familiaOlfativa" id="familiaOlfativa"></div>
        <div class="field"><label>Fixação</label><input type="text" name="fixacao" id="fixacao"></div>
      </div>
      <div class="field"><label>Notas de topo</label><input type="text" name="notasTopo" id="notasTopo"></div>
      <div class="field"><label>Notas de coração</label><input type="text" name="notasCoracao" id="notasCoracao"></div>
      <div class="field"><label>Notas de fundo</label><input type="text" name="notasFundo" id="notasFundo"></div>
      <div class="field-row">
        <div class="field"><label>Projeção</label><input type="text" name="projecao" id="projecao"></div>
        <div class="field"><label>Ocasião</label><input type="text" name="ocasiao" id="ocasiao"></div>
      </div>
      <div class="field"><label>Estação</label><input type="text" name="estacao" id="estacao"></div>

      <div id="form-msg" class="form-msg"></div>
      <div class="drawer-actions">
        <button type="submit" class="btn-admin btn-admin-primary btn-block" id="btn-salvar">Salvar produto</button>
      </div>
    </form>
  </div>
</div>

<script src="assets/js/admin.js?v=20260806a"></script>
</body>
</html>
