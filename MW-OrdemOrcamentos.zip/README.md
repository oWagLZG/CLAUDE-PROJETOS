# MW - ORDEM E ORÇAMENTOS

Aplicativo Desktop (Windows) para geração rápida de Ordens de Serviço e Orçamentos em PDF.
Desenvolvido em **C# / .NET 8 / WPF**, com geração de PDF via **QuestPDF**.
100% offline — sem banco de dados, sem internet, sem login.

---

## ⚠️ Pré-requisito importante

Este é um aplicativo **WPF para Windows**. Para rodar (`F5`) ou depurar a interface gráfica,
você precisa estar em uma máquina **Windows** com o VS Code. É possível editar o código em
qualquer sistema operacional, mas a compilação/execução do WPF exige Windows.

---

## 1. Instalar os pré-requisitos

1. **.NET 8 SDK** — baixe em: https://dotnet.microsoft.com/download/dotnet/8.0
   Confirme a instalação com:
   ```
   dotnet --version
   ```
   (deve mostrar `8.x.x`)

2. **VS Code** — https://code.visualstudio.com/

3. Abra a pasta `src` (a que contém `MW-OrdemOrcamentos.sln`) no VS Code:
   ```
   code .
   ```

4. Quando o VS Code abrir, ele vai sugerir instalar a extensão **C# Dev Kit**
   (já está na lista de recomendadas em `.vscode/extensions.json`). Instale-a.

---

## 2. Restaurar os pacotes NuGet

No terminal integrado do VS Code (`Ctrl+ '`), na pasta `src`:

```
dotnet restore MW-OrdemOrcamentos/MW-OrdemOrcamentos.csproj
```

Isso vai baixar o pacote **QuestPDF** automaticamente.

---

## 3. Rodar o aplicativo

**Opção A — pelo terminal:**
```
dotnet run --project MW-OrdemOrcamentos/MW-OrdemOrcamentos.csproj
```

**Opção B — pelo VS Code:**
Pressione `F5` (usa a configuração já pronta em `.vscode/launch.json`).

**Opção C — tarefa de build:**
`Ctrl+Shift+B` executa a task "build" (`.vscode/tasks.json`).

---

## 4. Gerar o executável final (.exe único, sem dependências)

Para gerar o `.exe` final, pronto para copiar para qualquer computador Windows
(sem precisar instalar .NET nele):

```
dotnet publish MW-OrdemOrcamentos/MW-OrdemOrcamentos.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
```

Ou use a task já configurada: **Terminal → Run Task → "publish (exe único)"**.

O executável final ficará em:
```
MW-OrdemOrcamentos/bin/Release/net8.0-windows/win-x64/publish/MW-OrdemOrcamentos.exe
```

Esse único arquivo `.exe` já pode ser copiado e distribuído — não precisa instalar nada
na máquina de destino.

---

## 5. Sobre a logo

O programa carrega automaticamente o arquivo:

```
MW-OrdemOrcamentos/Assets/logo.png
```

Este projeto já vem com uma **logo de exemplo (placeholder)** gerada automaticamente,
apenas para o programa funcionar imediatamente. **Substitua esse arquivo pela logo real
da empresa** (mesmo nome: `logo.png`) e recompile o projeto. A logo aparece tanto na
tela principal quanto no cabeçalho do PDF gerado.

O mesmo vale para o ícone do programa: `MW-OrdemOrcamentos/Assets/icon.ico`.

---

## 6. Estrutura do projeto

```
src/
├── MW-OrdemOrcamentos.sln
└── MW-OrdemOrcamentos/
    ├── MW-OrdemOrcamentos.csproj
    ├── App.xaml / App.xaml.cs          -> Inicialização (licença QuestPDF)
    ├── Assets/
    │   ├── logo.png                    -> Logo exibida na tela e no PDF
    │   └── icon.ico                    -> Ícone da janela/executável
    ├── Models/
    │   ├── ItemOrcamento.cs            -> Linha da tabela (Descrição/Qtd/Valor/Total)
    │   └── OrcamentoData.cs            -> Dados agregados para o PDF
    ├── Services/
    │   └── PdfService.cs               -> Geração do PDF com QuestPDF
    ├── Converters/
    │   └── CurrencyConverter.cs        -> Formatação de moeda nos bindings
    ├── Utils/
    │   ├── CurrencyHelper.cs           -> Máscara/formatação de moeda (R$)
    │   └── FileNameHelper.cs           -> Nome sugerido do arquivo PDF
    └── Views/
        ├── MainWindow.xaml             -> Interface principal
        └── MainWindow.xaml.cs          -> Lógica da tela
```

---

## 7. Funcionalidades

- Preenchimento de Data (automática, editável), Número do Documento, Cliente e Endereço.
- Tabela de itens dinâmica: adicionar/excluir linhas, cálculo automático de totais.
- Máscara de moeda em tempo real no campo Valor Unitário (ex.: `250` → `250,00`).
- Campo Quantidade aceita apenas números.
- Total Geral sempre recalculado, em destaque (verde, negrito).
- Observações em campo de texto livre (múltiplas linhas).
- Validações antes de gerar o PDF (Cliente obrigatório, ao menos 1 item).
- Geração de PDF em A4, pronto para impressão/WhatsApp, com nome sugerido
  `Orçamento - Nome do Cliente.pdf`.
- Pergunta "Deseja abrir o PDF?" após salvar.
- Atalhos: `Tab`/`Shift+Tab`/`Enter` para navegar entre campos, `Ctrl+Enter` para gerar o PDF.
- 100% offline, sem banco de dados, sem login, sem internet.

---

## 7.1. Se o `dotnet restore` falhar por causa da versão do QuestPDF

O `.csproj` referencia o pacote `QuestPDF` fixado na versão `2024.12.3`. Como este projeto foi
gerado sem acesso à internet, não foi possível confirmar em tempo real qual é a última versão
publicada no NuGet. Se o `dotnet restore` reclamar que essa versão não existe, basta atualizar
para a mais recente com:

```
dotnet remove MW-OrdemOrcamentos/MW-OrdemOrcamentos.csproj package QuestPDF
dotnet add MW-OrdemOrcamentos/MW-OrdemOrcamentos.csproj package QuestPDF
```

Isso reescreve automaticamente o `<PackageReference>` no `.csproj` com a versão estável mais
recente disponível. O restante do código (API fluente do QuestPDF usada em `PdfService.cs`) é
estável entre versões recentes e não deve exigir nenhuma alteração.

---

## 8. Licença do QuestPDF

O projeto usa a licença **Community** do QuestPDF (gratuita, configurada em `App.xaml.cs`),
adequada para uso comercial por pequenas empresas conforme os termos atuais da biblioteca.
Antes de uso comercial em maior escala, revise os termos de licenciamento em:
https://www.questpdf.com/license/
