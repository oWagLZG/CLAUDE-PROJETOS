using System.Windows;
using QuestPDF.Infrastructure;

namespace MW.OrdemOrcamentos;

/// <summary>
/// Ponto de entrada da aplicação. Responsável por configurar a licença
/// da biblioteca QuestPDF (uso gratuito - Community) antes de qualquer
/// geração de documento.
/// </summary>
public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // Licença Community da QuestPDF (gratuita para pequenas empresas).
        QuestPDF.Settings.License = LicenseType.Community;
    }
}
