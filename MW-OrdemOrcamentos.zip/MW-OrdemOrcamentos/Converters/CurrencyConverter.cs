using System.Globalization;
using System.Windows.Data;
using MW.OrdemOrcamentos.Utils;

namespace MW.OrdemOrcamentos.Converters;

/// <summary>
/// Converte um valor decimal para o formato de moeda brasileira exibido na tela
/// (ex.: 1234.5 -> "1.234,50"). Usado, por exemplo, na coluna Total de cada linha.
/// </summary>
public class CurrencyConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is decimal d)
            return CurrencyHelper.FormatValue(d);

        return "0,00";
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        throw new NotSupportedException("Conversão reversa não é utilizada nesta aplicação.");
    }
}
