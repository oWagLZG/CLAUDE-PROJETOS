using System.Globalization;
using System.Text;

namespace MW.OrdemOrcamentos.Utils;

/// <summary>
/// Funções utilitárias para formatação de valores em Real (R$) e
/// máscara de moeda "estilo caixa eletrônico" (dígitos entram pela direita).
/// </summary>
public static class CurrencyHelper
{
    public static readonly CultureInfo PtBr = new("pt-BR");

    /// <summary>
    /// Converte uma sequência de dígitos (ex.: "25000") em um valor decimal,
    /// tratando os dois últimos dígitos como centavos (ex.: 250,00).
    /// </summary>
    public static decimal DigitsToDecimal(string digitsOnly)
    {
        if (string.IsNullOrEmpty(digitsOnly))
            return 0m;

        // Remove zeros à esquerda excessivos, mas mantém ao menos "0"
        digitsOnly = digitsOnly.TrimStart('0');
        if (string.IsNullOrEmpty(digitsOnly))
            digitsOnly = "0";

        if (!long.TryParse(digitsOnly, NumberStyles.None, CultureInfo.InvariantCulture, out var raw))
            return 0m;

        return raw / 100m;
    }

    /// <summary>Formata um decimal como "250,00" (sem símbolo de moeda).</summary>
    public static string FormatValue(decimal value)
    {
        return value.ToString("N2", PtBr);
    }

    /// <summary>Formata um decimal como "R$ 250,00" (com símbolo de moeda).</summary>
    public static string FormatCurrency(decimal value)
    {
        return "R$ " + value.ToString("N2", PtBr);
    }

    /// <summary>Extrai somente os dígitos de uma string.</summary>
    public static string ExtractDigits(string input)
    {
        var sb = new StringBuilder();
        foreach (var c in input)
        {
            if (char.IsDigit(c))
                sb.Append(c);
        }
        return sb.ToString();
    }
}
