using System.IO;
using System.Linq;
using System.Text;

namespace MW.OrdemOrcamentos.Utils;

/// <summary>
/// Utilitário para gerar nomes de arquivo seguros a partir do nome do cliente.
/// </summary>
public static class FileNameHelper
{
    public static string SanitizeFileName(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            return "Cliente";

        var invalidChars = Path.GetInvalidFileNameChars();
        var sb = new StringBuilder();

        foreach (var c in name)
        {
            sb.Append(invalidChars.Contains(c) ? ' ' : c);
        }

        var result = sb.ToString().Trim();
        while (result.Contains("  "))
            result = result.Replace("  ", " ");

        return string.IsNullOrWhiteSpace(result) ? "Cliente" : result;
    }

    public static string BuildSuggestedFileName(string clienteNome)
    {
        return $"Orçamento - {SanitizeFileName(clienteNome)}.pdf";
    }
}
