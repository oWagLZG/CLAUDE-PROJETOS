using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace MW.OrdemOrcamentos.Models;

/// <summary>
/// Representa uma linha da tabela de itens do Orçamento / Ordem de Serviço.
/// O Total é sempre calculado automaticamente (Quantidade x Valor Unitário)
/// e nunca pode ser editado diretamente pelo usuário.
/// </summary>
public class ItemOrcamento : INotifyPropertyChanged
{
    private string _descricao = string.Empty;
    private int _quantidade = 1;
    private decimal _valorUnitario = 0m;

    /// <summary>Descrição do serviço/produto.</summary>
    public string Descricao
    {
        get => _descricao;
        set
        {
            if (_descricao == value) return;
            _descricao = value;
            OnPropertyChanged();
        }
    }

    /// <summary>Quantidade (somente números inteiros positivos).</summary>
    public int Quantidade
    {
        get => _quantidade;
        set
        {
            if (_quantidade == value) return;
            _quantidade = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(Total));
        }
    }

    /// <summary>Valor unitário em moeda brasileira (R$).</summary>
    public decimal ValorUnitario
    {
        get => _valorUnitario;
        set
        {
            if (_valorUnitario == value) return;
            _valorUnitario = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(Total));
        }
    }

    /// <summary>Total da linha. Sempre recalculado, nunca editável.</summary>
    public decimal Total => Quantidade * ValorUnitario;

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
