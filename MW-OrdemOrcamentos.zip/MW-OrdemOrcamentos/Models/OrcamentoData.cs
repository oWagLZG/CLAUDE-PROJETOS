namespace MW.OrdemOrcamentos.Models;

/// <summary>
/// Estrutura simples que agrupa todos os dados preenchidos na tela,
/// pronta para ser entregue ao gerador de PDF.
/// </summary>
public class OrcamentoData
{
    public string Data { get; set; } = string.Empty;
    public string NumeroDocumento { get; set; } = string.Empty;
    public string Cliente { get; set; } = string.Empty;
    public string Endereco { get; set; } = string.Empty;
    public string Observacoes { get; set; } = string.Empty;
    public List<ItemOrcamento> Itens { get; set; } = new();
    public decimal TotalGeral { get; set; }
}
