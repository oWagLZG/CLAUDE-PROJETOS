using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using Microsoft.Win32;
using MW.OrdemOrcamentos.Models;
using MW.OrdemOrcamentos.Services;
using MW.OrdemOrcamentos.Utils;

namespace MW.OrdemOrcamentos.Views;

/// <summary>
/// Janela principal da aplicação. Contém toda a lógica de interação da tela
/// de Ordem de Serviço / Orçamento: itens dinâmicos, cálculo de totais,
/// máscara de moeda em tempo real, validações e geração do PDF final.
/// </summary>
public partial class MainWindow : Window
{
    private readonly ObservableCollection<ItemOrcamento> _itens = new();
    private bool _isFormattingValor;
    private bool _isSanitizingQuantidade;

    public MainWindow()
    {
        InitializeComponent();

        DataTextBox.Text = DateTime.Now.ToString("dd/MM/yyyy", CurrencyHelper.PtBr);

        ItensItemsControl.ItemsSource = _itens;

        // Inicia o formulário com uma única linha, conforme especificado.
        _itens.Add(new ItemOrcamento());

        AtualizarTotalGeral();
    }

    // ==================================================================
    //  ITENS DA TABELA
    // ==================================================================

    private void AdicionarItem_Click(object sender, RoutedEventArgs e)
    {
        _itens.Add(new ItemOrcamento());
        AtualizarTotalGeral();
    }

    private void ExcluirItem_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not FrameworkElement fe || fe.DataContext is not ItemOrcamento item)
            return;

        _itens.Remove(item);
        AtualizarTotalGeral();
    }

    private void AtualizarTotalGeral()
    {
        var total = _itens.Sum(i => i.Total);
        TotalGeralTextBlock.Text = CurrencyHelper.FormatCurrency(total);
    }

    // ==================================================================
    //  CAMPO QUANTIDADE — aceita apenas números inteiros
    // ==================================================================

    private void QuantidadeTextBox_Loaded(object sender, RoutedEventArgs e)
    {
        if (sender is not System.Windows.Controls.TextBox tb) return;
        if (tb.DataContext is not ItemOrcamento item) return;

        tb.Text = item.Quantidade.ToString(CultureInfo.InvariantCulture);
    }

    private void QuantidadeTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
    {
        e.Handled = !e.Text.All(char.IsDigit);
    }

    private void QuantidadeTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (_isSanitizingQuantidade) return;
        if (sender is not System.Windows.Controls.TextBox tb) return;
        if (tb.DataContext is not ItemOrcamento item) return;

        var digits = CurrencyHelper.ExtractDigits(tb.Text);

        if (digits != tb.Text)
        {
            _isSanitizingQuantidade = true;
            var caret = tb.CaretIndex - (tb.Text.Length - digits.Length);
            tb.Text = digits;
            tb.CaretIndex = Math.Max(0, Math.Min(caret, tb.Text.Length));
            _isSanitizingQuantidade = false;
        }

        item.Quantidade = string.IsNullOrEmpty(digits) ? 0 : int.Parse(digits, CultureInfo.InvariantCulture);
        AtualizarTotalGeral();
    }

    // ==================================================================
    //  CAMPO VALOR UNITÁRIO — máscara de moeda brasileira em tempo real
    // ==================================================================

    private void ValorUnitarioTextBox_Loaded(object sender, RoutedEventArgs e)
    {
        if (sender is not System.Windows.Controls.TextBox tb) return;
        if (tb.DataContext is not ItemOrcamento item) return;

        tb.Text = CurrencyHelper.FormatValue(item.ValorUnitario);
    }

    private void ValorUnitarioTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
    {
        e.Handled = !e.Text.All(char.IsDigit);
    }

    private void ValorUnitarioTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (_isFormattingValor) return;
        if (sender is not System.Windows.Controls.TextBox tb) return;
        if (tb.DataContext is not ItemOrcamento item) return;

        var digits = CurrencyHelper.ExtractDigits(tb.Text);
        var valor = CurrencyHelper.DigitsToDecimal(digits);
        var formatado = CurrencyHelper.FormatValue(valor);

        item.ValorUnitario = valor;

        if (tb.Text != formatado)
        {
            _isFormattingValor = true;
            tb.Text = formatado;
            tb.CaretIndex = tb.Text.Length;
            _isFormattingValor = false;
        }

        AtualizarTotalGeral();
    }

    // ==================================================================
    //  ATALHOS DE TECLADO
    // ==================================================================

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        // CTRL + ENTER -> Gerar PDF imediatamente, de qualquer campo.
        if (e.Key == Key.Enter && Keyboard.Modifiers == ModifierKeys.Control)
        {
            e.Handled = true;
            GerarPdf_Click(this, new RoutedEventArgs());
            return;
        }

        // ENTER -> avança para o próximo campo (exceto em campos multilinha).
        if (e.Key == Key.Enter && Keyboard.Modifiers == ModifierKeys.None)
        {
            if (Keyboard.FocusedElement is System.Windows.Controls.TextBox tb && tb.AcceptsReturn)
                return;

            if (Keyboard.FocusedElement is UIElement focused)
            {
                e.Handled = true;
                focused.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
            }
        }
    }

    // ==================================================================
    //  GERAÇÃO DO PDF
    // ==================================================================

    private void GerarPdf_Click(object sender, RoutedEventArgs e)
    {
        if (!ValidarFormulario(out var mensagemErro))
        {
            MessageBox.Show(mensagemErro, "MW - Ordem e Orçamentos",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var dados = new OrcamentoData
        {
            Data = DataTextBox.Text.Trim(),
            NumeroDocumento = NumeroDocumentoTextBox.Text.Trim(),
            Cliente = ClienteTextBox.Text.Trim(),
            Endereco = EnderecoTextBox.Text.Trim(),
            Observacoes = ObservacoesTextBox.Text.Trim(),
            Itens = _itens.Where(i => !string.IsNullOrWhiteSpace(i.Descricao)).ToList(),
            TotalGeral = _itens.Sum(i => i.Total)
        };

        var saveDialog = new SaveFileDialog
        {
            Filter = "Arquivo PDF (*.pdf)|*.pdf",
            FileName = FileNameHelper.BuildSuggestedFileName(dados.Cliente),
            DefaultExt = ".pdf",
            AddExtension = true
        };

        if (saveDialog.ShowDialog(this) != true)
            return;

        try
        {
            PdfService.Gerar(dados, saveDialog.FileName);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                $"Não foi possível gerar o PDF.\n\nDetalhes: {ex.Message}",
                "MW - Ordem e Orçamentos",
                MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        var resultado = MessageBox.Show(
            "PDF salvo com sucesso!\n\nDeseja abrir o PDF agora?",
            "MW - Ordem e Orçamentos",
            MessageBoxButton.YesNo, MessageBoxImage.Question);

        if (resultado == MessageBoxResult.Yes)
        {
            try
            {
                var processInfo = new System.Diagnostics.ProcessStartInfo(saveDialog.FileName)
                {
                    UseShellExecute = true
                };
                System.Diagnostics.Process.Start(processInfo);
            }
            catch
            {
                MessageBox.Show(
                    "Não foi possível abrir o PDF automaticamente. Localize o arquivo salvo manualmente.",
                    "MW - Ordem e Orçamentos",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }

    private bool ValidarFormulario(out string mensagemErro)
    {
        if (string.IsNullOrWhiteSpace(ClienteTextBox.Text))
        {
            mensagemErro = "Por favor, informe o nome do Cliente antes de gerar o PDF.";
            ClienteTextBox.Focus();
            return false;
        }

        var itensValidos = _itens.Where(i => !string.IsNullOrWhiteSpace(i.Descricao)).ToList();

        if (itensValidos.Count == 0)
        {
            mensagemErro = "Adicione pelo menos um item com descrição antes de gerar o PDF.";
            return false;
        }

        mensagemErro = string.Empty;
        return true;
    }
}
