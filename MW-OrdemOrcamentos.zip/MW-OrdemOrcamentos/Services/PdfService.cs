using System.IO;
using System.Windows;
using System.Windows.Resources;
using MW.OrdemOrcamentos.Models;
using MW.OrdemOrcamentos.Utils;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace MW.OrdemOrcamentos.Services;

/// <summary>
/// Responsável por montar e salvar o PDF final da Ordem de Serviço / Orçamento
/// utilizando a biblioteca QuestPDF. O layout é moderno, em A4, pronto para
/// impressão ou envio digital (WhatsApp/e-mail).
/// </summary>
public static class PdfService
{
    // ==================================================================
    //  DADOS DA EMPRESA
    //  Edite estas constantes para atualizar as informações que aparecem
    //  no cabeçalho do PDF (nome, telefones, e-mail e CNPJ).
    // ==================================================================
    private const string NomeEmpresa = "MW SOLUÇÕES ELÉTRICAS E SEGURANÇA";
    private const string TelefonesEmpresa = "(47) 9 8822-6777 ou (47) 9 9978-5115";
    private const string EmailEmpresa = "mwsegurancas@gmail.com";
    private const string CnpjEmpresa = "54.048.360/0001-92";

    // Cor de destaque da marca (usada no título, na tabela e no total).
    private static readonly string CorDestaque = "#0E7C86";
    private static readonly string CorDestaqueEscura = "#0A5C64";

    public static void Gerar(OrcamentoData dados, string caminhoArquivo)
    {
        var logoBytes = CarregarLogoBytes();

        var document = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(34);
                page.DefaultTextStyle(x => x.FontFamily("Segoe UI").FontSize(10));

                page.Header().Element(c => ComposeHeader(c, dados, logoBytes));
                page.Content().Element(c => ComposeContent(c, dados));
                page.Footer().Element(ComposeFooter);
            });
        });

        document.GeneratePdf(caminhoArquivo);
    }

    // ==================================================================
    //  CABEÇALHO
    // ==================================================================

    private static void ComposeHeader(IContainer container, OrcamentoData dados, byte[]? logoBytes)
    {
        container.Column(column =>
        {
            // Linha 1: dados da empresa (esquerda) + logo (direita)
            column.Item().Row(row =>
            {
                row.RelativeItem().Column(col =>
                {
                    col.Item().Text(NomeEmpresa)
                        .FontSize(13).Bold().FontColor(Colors.Grey.Darken4);

                    col.Item().PaddingTop(4).Text($"Telefone: {TelefonesEmpresa}")
                        .FontSize(8.5f).FontColor(Colors.Grey.Darken2);

                    col.Item().PaddingTop(1).Text($"E-mail: {EmailEmpresa}")
                        .FontSize(8.5f).FontColor(Colors.Grey.Darken2);

                    col.Item().PaddingTop(1).Text($"CNPJ: {CnpjEmpresa}")
                        .FontSize(8.5f).FontColor(Colors.Grey.Darken2);
                });

                row.ConstantItem(78).Height(78).AlignMiddle().AlignRight().Element(e =>
                {
                    if (logoBytes is { Length: > 0 })
                        e.Image(logoBytes).FitArea();
                    else
                        e.AlignMiddle().AlignCenter().Text("MW").FontSize(28).Bold().FontColor(Colors.Grey.Darken4);
                });
            });

            // Faixa de destaque com o título do documento
            column.Item().PaddingTop(14).Background(CorDestaque).Padding(10)
                .Text("ORDEM DE SERVIÇO / ORÇAMENTO")
                .FontSize(15).Bold().FontColor(Colors.White);
        });
    }

    // ==================================================================
    //  CONTEÚDO PRINCIPAL
    // ==================================================================

    private static void ComposeContent(IContainer container, OrcamentoData dados)
    {
        container.PaddingTop(16).Column(column =>
        {
            column.Spacing(16);

            // Bloco Cliente / Data / Endereço / Nº Documento em grade 2x2
            column.Item().Background(Colors.Grey.Lighten5).Padding(14).Column(gridColumn =>
            {
                gridColumn.Spacing(8);

                gridColumn.Item().Row(row =>
                {
                    row.RelativeItem(2).Element(e => CampoInfo(e, "CLIENTE", dados.Cliente));
                    row.RelativeItem(1).Element(e => CampoInfo(e, "DATA", dados.Data));
                });

                gridColumn.Item().Row(row =>
                {
                    row.RelativeItem(2).Element(e => CampoInfo(e, "ENDEREÇO",
                        string.IsNullOrWhiteSpace(dados.Endereco) ? "-" : dados.Endereco));
                    row.RelativeItem(1).Element(e => CampoInfo(e, "Nº DOCUMENTO",
                        string.IsNullOrWhiteSpace(dados.NumeroDocumento) ? "-" : dados.NumeroDocumento));
                });
            });

            // Tabela de itens
            column.Item().Element(c => ComposeTabela(c, dados));

            // Total geral — bem grande e em destaque, como no modelo de referência.
            column.Item().PaddingTop(4).AlignRight().Text(text =>
            {
                text.Span("TOTAL:  ").FontSize(16).SemiBold().FontColor(Colors.Grey.Darken2);
                text.Span(CurrencyHelper.FormatCurrency(dados.TotalGeral))
                    .FontSize(30).Bold().FontColor(CorDestaqueEscura);
            });

            // Observações
            if (!string.IsNullOrWhiteSpace(dados.Observacoes))
            {
                column.Item().Column(c =>
                {
                    c.Item().Text("OBSERVAÇÕES").FontSize(9).SemiBold().FontColor(Colors.Grey.Darken1);
                    c.Item().PaddingTop(5).Background(Colors.Grey.Lighten5)
                        .BorderLeft(3).BorderColor(CorDestaque)
                        .Padding(10)
                        .Text(dados.Observacoes).FontSize(10).FontColor(Colors.Grey.Darken3).LineHeight(1.4f);
                });
            }
        });
    }

    /// <summary>Renderiza um par "RÓTULO" + valor, usado na grade Cliente/Data/Endereço/Documento.</summary>
    private static void CampoInfo(IContainer container, string rotulo, string valor)
    {
        container.Column(c =>
        {
            c.Item().Text(rotulo).FontSize(8).SemiBold().FontColor(Colors.Grey.Darken1);
            c.Item().PaddingTop(2).Text(string.IsNullOrWhiteSpace(valor) ? "-" : valor)
                .FontSize(11.5f).SemiBold().FontColor(Colors.Grey.Darken4);
        });
    }

    // ==================================================================
    //  TABELA DE ITENS
    // ==================================================================

    private static void ComposeTabela(IContainer container, OrcamentoData dados)
    {
        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.RelativeColumn(4f);
                columns.RelativeColumn(1f);
                columns.RelativeColumn(1.5f);
                columns.RelativeColumn(1.5f);
            });

            table.Header(header =>
            {
                header.Cell().Element(HeaderCellStyle).Text("SERVIÇO / PRODUTO");
                header.Cell().Element(HeaderCellStyle).AlignCenter().Text("QTD");
                header.Cell().Element(HeaderCellStyle).AlignRight().Text("VALOR UNIT.");
                header.Cell().Element(HeaderCellStyle).AlignRight().Text("TOTAL");
            });

            foreach (var item in dados.Itens)
            {
                table.Cell().Element(BodyCellStyle).Text(item.Descricao)
                    .FontSize(10.5f).FontColor(Colors.Grey.Darken4);

                table.Cell().Element(BodyCellStyle).AlignCenter()
                    .Text(item.Quantidade.ToString()).FontSize(10.5f).FontColor(Colors.Grey.Darken4);

                table.Cell().Element(BodyCellStyle).AlignRight()
                    .Text(CurrencyHelper.FormatValue(item.ValorUnitario)).FontSize(10.5f).FontColor(Colors.Grey.Darken4);

                table.Cell().Element(BodyCellStyle).AlignRight()
                    .Text(CurrencyHelper.FormatValue(item.Total)).FontSize(10.5f).SemiBold().FontColor(Colors.Grey.Darken4);
            }
        });
    }

    private static IContainer HeaderCellStyle(IContainer container)
    {
        return container
            .BorderBottom(1.5f)
            .BorderColor(Colors.Grey.Darken2)
            .PaddingVertical(8)
            .PaddingHorizontal(6)
            .DefaultTextStyle(x => x.FontColor(Colors.Grey.Darken3).FontSize(9).SemiBold());
    }

    private static IContainer BodyCellStyle(IContainer container)
    {
        return container
            .BorderBottom(1)
            .BorderColor(Colors.Grey.Lighten2)
            .PaddingVertical(10)
            .PaddingHorizontal(6);
    }

    // ==================================================================
    //  RODAPÉ
    // ==================================================================

    private static void ComposeFooter(IContainer container)
    {
        container.Column(column =>
        {
            column.Item().PaddingBottom(6).LineHorizontal(1).LineColor(Colors.Grey.Lighten3);

            column.Item().Row(row =>
            {
                row.RelativeItem().Text(NomeEmpresa)
                    .FontSize(8).FontColor(Colors.Grey.Darken1);

                row.RelativeItem().AlignRight().Text(text =>
                {
                    text.DefaultTextStyle(x => x.FontSize(8).FontColor(Colors.Grey.Darken1));
                    text.Span("Página ");
                    text.CurrentPageNumber();
                    text.Span(" de ");
                    text.TotalPages();
                });
            });
        });
    }

    // ==================================================================
    //  LOGO
    // ==================================================================

    /// <summary>
    /// Carrega os bytes do logo embutido em Assets/logo.png (recurso do WPF)
    /// para ser utilizado na geração do PDF. Retorna null se não encontrado,
    /// permitindo que o cabeçalho use um texto substituto ("MW").
    /// </summary>
    private static byte[]? CarregarLogoBytes()
    {
        try
        {
            var uri = new Uri("pack://application:,,,/Assets/logo.png", UriKind.Absolute);
            StreamResourceInfo? info = Application.GetResourceStream(uri);

            if (info?.Stream == null)
                return null;

            using var memoryStream = new MemoryStream();
            info.Stream.CopyTo(memoryStream);
            return memoryStream.ToArray();
        }
        catch
        {
            return null;
        }
    }
}
