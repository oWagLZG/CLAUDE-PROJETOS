// ============================================================
// PLASANDRE — interações
// ============================================================

document.addEventListener("DOMContentLoaded", () => {
  /* Partículas do hero — flocos translúcidos gerados uma vez, via JS,
     pra não pesar o HTML com dezenas de <span> estáticos */
  const particleField = document.getElementById("heroParticles");
  if (particleField) {
    const count = window.innerWidth < 720 ? 10 : 22;
    for (let i = 0; i < count; i++) {
      const p = document.createElement("span");
      p.style.setProperty("--x", `${Math.random() * 100}%`);
      p.style.setProperty("--y", `${20 + Math.random() * 70}%`);
      p.style.setProperty("--s", `${3 + Math.random() * 4}px`);
      p.style.setProperty("--dur", `${10 + Math.random() * 10}s`);
      p.style.setProperty("--delay", `${Math.random() * 8}s`);
      particleField.appendChild(p);
    }
  }

  /* Trilho de produção — preenchimento e estação ativa conforme a rolagem */
  const railFill = document.getElementById("railFill");
  const mobileFill = document.getElementById("mobileRailFill");
  const stations = document.querySelectorAll(".rail-station");
  const sections = Array.from(stations).map((s) => document.getElementById(s.dataset.target)).filter(Boolean);

  stations.forEach((station, i) => {
    const total = stations.length - 1;
    station.style.top = `${(i / total) * 100}%`;
    station.addEventListener("click", () => {
      sections[i]?.scrollIntoView({ behavior: "smooth" });
    });
    station.style.cursor = "pointer";
  });

  const updateRail = () => {
    const doc = document.documentElement;
    const scrollable = doc.scrollHeight - window.innerHeight;
    const pct = scrollable > 0 ? Math.min(1, Math.max(0, window.scrollY / scrollable)) : 0;

    if (railFill) railFill.style.height = `${pct * 100}%`;
    if (mobileFill) mobileFill.style.width = `${pct * 100}%`;

    if (sections.length) {
      let activeIndex = 0;
      sections.forEach((sec, i) => {
        if (sec.getBoundingClientRect().top < window.innerHeight * 0.5) activeIndex = i;
      });
      stations.forEach((s, i) => s.classList.toggle("active", i === activeIndex));
    }
  };
  updateRail();
  window.addEventListener("scroll", updateRail, { passive: true });
  window.addEventListener("resize", updateRail);


  document.querySelectorAll(".product-card").forEach((card) => {
    const strength = 10;
    card.addEventListener("mousemove", (e) => {
      const r = card.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      card.classList.remove("settling");
      card.style.transform = `perspective(800px) rotateY(${px * strength}deg) rotateX(${-py * strength}deg) translateY(-6px)`;
    });
    card.addEventListener("mouseleave", () => {
      card.classList.add("settling");
      card.style.transform = "perspective(800px) rotateY(0deg) rotateX(0deg) translateY(0)";
    });
  });

  /* Header muda de estado ao rolar */
  const header = document.querySelector(".site-header");
  const onScroll = () => {
    if (window.scrollY > 40) header.classList.add("scrolled");
    else header.classList.remove("scrolled");
  };
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  /* Menu mobile simples */
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", () => {
      const open = links.style.display === "flex";
      links.style.cssText = open
        ? ""
        : "display:flex;flex-direction:column;position:fixed;top:64px;left:0;right:0;background:#f6f7f5;padding:24px;gap:18px;box-shadow:0 12px 24px rgba(0,0,0,0.12);";
      if (!open) links.querySelectorAll("a").forEach(a => (a.style.color = "#12181f"));
    });
  }

  /* Revela seções/cards ao entrar na tela */
  const revealTargets = document.querySelectorAll(".reveal, .reveal-stagger, .diff-card");
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          io.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  revealTargets.forEach((el) => io.observe(el));

  /* Miniaturas trocam a imagem principal do card */
  document.querySelectorAll(".thumbs").forEach((row) => {
    const main = row.previousElementSibling?.querySelector("img");
    if (!main) return;
    row.querySelectorAll("img").forEach((thumb) => {
      thumb.addEventListener("click", () => {
        const tmp = main.src;
        main.src = thumb.src;
        thumb.src = tmp;
      });
    });
  });

  /* Filtro de categorias no catálogo */
  const tabs = document.querySelectorAll(".cat-tab");
  const cards = document.querySelectorAll(".product-card");
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
      const cat = tab.dataset.cat;
      cards.forEach((card) => {
        const match = cat === "todos" || card.dataset.cat === cat;
        card.classList.toggle("hidden", !match);
      });
    });
  });
});
